# src/itoformer/models/blocks/utils.py
import torch

def build_causal_mask(T: int, device: torch.device, dtype: torch.dtype = torch.float32, large_neg: float = -1e9) -> torch.Tensor:
    """
    Returns an additive mask of shape [1, 1, T, T] with 0. on allowed positions
    and a large negative number on disallowed (future) positions.
    """
    # upper-triangular (strict) are the future positions we want to block
    future = torch.triu(torch.ones((T, T), device=device, dtype=torch.bool), diagonal=1)
    mask = torch.zeros((T, T), device=device, dtype=dtype)
    mask = mask.masked_fill(future, large_neg)
    return mask.unsqueeze(0).unsqueeze(0)  # [1,1,T,T]
