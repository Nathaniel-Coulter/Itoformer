# src/itoformer/models/blocks/state_token.py
from __future__ import annotations
from typing import Optional

import torch
import torch.nn as nn


class StateToken(nn.Module):
    """
    A persistent state token per 'cluster' (or shared) that is concatenated
    to the time dimension: input [B,T,A,D] -> output [B,T+1,A,D].
    The token can be updated via EMA with the current CLS-like summary.
    """
    def __init__(
        self,
        d_model: int,
        shared: bool = True,
        n_clusters: int = 1,
        ema: float = 0.0,
    ):
        """
        d_model: embedding dim
        shared: if True, single learnable token shared across all assets/clusters.
        n_clusters: if shared=False, number of distinct tokens (e.g., sectors)
        ema: if >0, exponential moving average update with batch summary
        """
        super().__init__()
        self.d_model = d_model
        self.shared = shared
        self.n_clusters = n_clusters
        self.ema = ema

        if shared:
            self.state = nn.Parameter(torch.zeros(1, 1, 1, d_model))
            nn.init.trunc_normal_(self.state, std=0.02)
        else:
            self.state = nn.Parameter(torch.zeros(1, 1, n_clusters, d_model))
            nn.init.trunc_normal_(self.state, std=0.02)

    def forward(
        self,
        x: torch.Tensor,
        cluster_idx: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        x: [B, T, A, D]
        cluster_idx: optional [A] long tensor mapping assets -> cluster id (0..n_clusters-1)
        returns: [B, T+1, A, D] with the state token at t=0 (broadcast across A if shared)
        """
        B, T, A, D = x.shape
        if self.shared:
            token = self.state.expand(B, 1, A, D)  # broadcast across assets
        else:
            assert cluster_idx is not None, "cluster_idx required when shared=False"
            # build per-asset token by indexing the cluster bank
            bank = self.state.squeeze(0).squeeze(0)  # [C, D]
            tok = bank[cluster_idx]                  # [A, D]
            token = tok.view(1, 1, A, D).expand(B, 1, A, D)

        x_cat = torch.cat([token, x], dim=1)  # prepend in time
        return x_cat

    @torch.no_grad()
    def update(self, summary: torch.Tensor):
        """
        Optional EMA update of the token with a provided summary statistic.
        summary: [1, 1, 1, D] (shared) or [1, 1, C, D] (clustered)
        """
        if self.ema <= 0.0:
            return
        self.state.data.lerp_(summary.to(self.state.dtype), self.ema)
