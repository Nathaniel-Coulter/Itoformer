# src/itoformer/models/blocks/normalization.py
from __future__ import annotations
import torch
import torch.nn as nn

class RMSNorm(nn.Module):
    """
    Root Mean Square Layer Normalization (no affine by default; add if desired).
    Reference: Zhang & Sennrich, 2019. Stable, lighter than LayerNorm.
    """
    def __init__(self, d_model: int, eps: float = 1e-8, affine: bool = True):
        super().__init__()
        self.eps = eps
        self.affine = affine
        if affine:
            self.weight = nn.Parameter(torch.ones(d_model))
        else:
            self.register_parameter("weight", None)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [..., d_model]
        rms = x.pow(2).mean(dim=-1, keepdim=True).add(self.eps).sqrt()
        x_hat = x / rms
        if self.affine:
            x_hat = x_hat * self.weight
        return x_hat
