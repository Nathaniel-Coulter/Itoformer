# src/itoformer/models/blocks/attention.py
from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F
from .utils import build_causal_mask

_HAS_SDP = hasattr(F, "scaled_dot_product_attention")

class ItoAttention(nn.Module):
    """
    Multi-head causal attention with optional additive Itô/stochastic biases.
    Bias tensor B is additive to logits, shape [B or 1, H, T, T].
    """
    def __init__(
        self,
        d_model: int,
        n_heads: int,
        attn_dropout: float = 0.0,
        proj_dropout: float = 0.0,
        use_bias: bool = True,
    ):
        super().__init__()
        assert d_model % n_heads == 0, "d_model must be divisible by n_heads"
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_head = d_model // n_heads
        self.qkv = nn.Linear(d_model, 3 * d_model, bias=use_bias)
        self.out = nn.Linear(d_model, d_model, bias=True)
        self.attn_dropout = attn_dropout
        self.proj_dropout = nn.Dropout(proj_dropout)

    def forward(
        self,
        x: torch.Tensor,                   # [B, T, d_model]
        bias: torch.Tensor | None = None,  # [B or 1, H, T, T]
    ) -> torch.Tensor:                     # -> [B, T, d_model]
        B, T, _ = x.shape
        qkv = self.qkv(x)  # [B, T, 3*d_model]
        qkv = qkv.view(B, T, 3, self.n_heads, self.d_head).transpose(1, 3)  # [B, H, 3, T, d_head]
        q, k, v = qkv[:, :, 0], qkv[:, :, 1], qkv[:, :, 2]                   # each [B, H, T, d_head]

        # Additive causal mask (shape [1,1,T,T]) then broadcast
        add_mask = build_causal_mask(T, x.device)  # [1,1,T,T]
        if bias is not None:
            # ensure bias shape broadcastable to [B,H,T,T]
            if bias.dim() == 4:
                # ok
                pass
            elif bias.dim() == 3:
                bias = bias.unsqueeze(0)  # assume [H,T,T] -> [1,H,T,T]
            else:
                raise ValueError("bias must be [B or 1, H, T, T] or [H,T,T]")

            add_mask = add_mask + bias  # additive to logits

        if _HAS_SDP:
            # PyTorch 2.x fused attention (fast, numerically stable).
            # attn_mask is additive in PyTorch 2.1+; else we emulate below.
            # We fold add_mask into 'attn_mask' if supported; otherwise fallback.
            try:
                # scaled_dot_product_attention expects [B,H,T,d] → we permute to [B*H, T, d]
                q_ = q.transpose(1, 2)  # [B,T,H,d]
                k_ = k.transpose(1, 2)
                v_ = v.transpose(1, 2)
                q_ = q_.reshape(B * self.n_heads, T, self.d_head)
                k_ = k_.reshape(B * self.n_heads, T, self.d_head)
                v_ = v_.reshape(B * self.n_heads, T, self.d_head)

                # Build attn_mask for fused path: [B*H, T, T]
                attn_mask = add_mask.expand(B, self.n_heads, T, T).reshape(B * self.n_heads, T, T)

                out = F.scaled_dot_product_attention(
                    q_, k_, v_,
                    attn_mask=attn_mask,  # additive in new PyTorch
                    dropout_p=self.attn_dropout if self.training else 0.0,
                    is_causal=False,      # causality is already in mask
                )  # [B*H, T, d_head]
                out = out.reshape(B, self.n_heads, T, self.d_head).transpose(1, 2).contiguous()  # [B,T,H,d]
                out = out.view(B, T, self.d_model)  # [B,T,d_model]
            except TypeError:
                # Older torch: fall back to manual logits path
                out = self._manual_attention(q, k, v, add_mask, dropout_p=self.attn_dropout)
        else:
            out = self._manual_attention(q, k, v, add_mask, dropout_p=self.attn_dropout)

        out = self.out(out)
        out = self.proj_dropout(out)
        return out

    def _manual_attention(
        self,
        q: torch.Tensor, k: torch.Tensor, v: torch.Tensor,
        add_mask: torch.Tensor,
        dropout_p: float,
    ) -> torch.Tensor:
        """
        Manual scaled dot-prod attention with additive masks.
        q,k,v: [B,H,T,d_head], add_mask: [1 or B, 1 or H, T, T]
        """
        B, H, T, Dh = q.shape
        scale = 1.0 / (Dh ** 0.5)
        logits = torch.einsum("bhtd,bhsd->bhts", q, k) * scale  # [B,H,T,T]
        logits = logits + add_mask  # causality + optional Ito biases
        attn = torch.softmax(logits, dim=-1)
        if dropout_p and self.training:
            attn = nn.functional.dropout(attn, p=dropout_p)
        out = torch.einsum("bhts,bhsd->bhtd", attn, v)  # [B,H,T,Dh]
        out = out.transpose(1, 2).contiguous().view(B, T, H * Dh)
        return out
