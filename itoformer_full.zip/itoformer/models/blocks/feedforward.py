# src/itoformer/models/blocks/feedforward.py
from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F

class SwiGLU(nn.Module):
    """
    SWiGLU feedforward block (Shazeer, 2020). Good performance/efficiency.
    ff_dim ~ 2-4x d_model is typical; 2x is a sweet spot.
    """
    def __init__(self, d_model: int, ff_mult: float = 2.0, dropout: float = 0.0):
        super().__init__()
        inner = int(d_model * ff_mult)
        self.w1 = nn.Linear(d_model, inner, bias=True)
        self.w2 = nn.Linear(d_model, inner, bias=True)
        self.w3 = nn.Linear(inner, d_model, bias=True)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        u = self.w1(x)
        v = self.w2(x)
        x = F.silu(u) * v  # SiLU(u) ⊗ v  (the “SwiGLU” gating)
        x = self.w3(self.dropout(x))
        return x
