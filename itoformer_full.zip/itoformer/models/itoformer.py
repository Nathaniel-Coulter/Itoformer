# src/itoformer/models/itoformer.py
from __future__ import annotations
from dataclasses import dataclass
import torch
import torch.nn as nn

from .blocks.attention import ItoAttention
from .blocks.feedforward import SwiGLU
from .blocks.normalization import RMSNorm
from .blocks.utils import build_causal_mask


@dataclass
class ItoConfig:
    n_assets: int
    in_features: int            # features per asset at each time
    d_model: int = 256
    n_layers: int = 6
    n_heads: int = 8
    ff_mult: float = 2.0
    attn_dropout: float = 0.0
    ffn_dropout: float = 0.0
    resid_dropout: float = 0.0
    use_rmsnorm: bool = True
    use_bias: bool = True
    max_len: int = 2048         # for positional embedding if needed
    pos_embed: bool = True


class ItoBlock(nn.Module):
    def __init__(self, cfg: ItoConfig):
        super().__init__()
        Norm = RMSNorm if cfg.use_rmsnorm else nn.LayerNorm
        self.norm1 = Norm(cfg.d_model)
        self.attn = ItoAttention(
            cfg.d_model,
            cfg.n_heads,
            attn_dropout=cfg.attn_dropout,
            proj_dropout=cfg.resid_dropout,
            use_bias=cfg.use_bias,
        )
        self.norm2 = Norm(cfg.d_model)
        self.ffn = SwiGLU(cfg.d_model, ff_mult=cfg.ff_mult, dropout=cfg.ffn_dropout)
        self.resid_dropout = nn.Dropout(cfg.resid_dropout)

    def forward(self, x: torch.Tensor, bias: torch.Tensor | None = None) -> torch.Tensor:
        # Pre-Norm block
        h = self.attn(self.norm1(x), bias=bias)
        x = x + self.resid_dropout(h)
        h = self.ffn(self.norm2(x))
        x = x + self.resid_dropout(h)
        return x


class ItoFormer(nn.Module):
    """
    Finance-native Transformer backbone supporting multiple heads (forecast, options_node, svi, term_structure).
    Expects input X: [B, T, A, F].
    """
    def __init__(self, cfg: ItoConfig, heads: dict[str, nn.Module]):
        super().__init__()
        self.cfg = cfg
        self.n_assets = cfg.n_assets
        self.in_features = cfg.in_features
        self.d_model = cfg.d_model

        in_dim = cfg.n_assets * cfg.in_features
        self.input_proj = nn.Linear(in_dim, cfg.d_model)

        if cfg.pos_embed:
            self.pos_emb = nn.Parameter(torch.zeros(1, cfg.max_len, cfg.d_model))
            nn.init.normal_(self.pos_emb, mean=0.0, std=0.02)
        else:
            self.register_parameter("pos_emb", None)

        self.blocks = nn.ModuleList([ItoBlock(cfg) for _ in range(cfg.n_layers)])
        self.norm_out = RMSNorm(cfg.d_model) if cfg.use_rmsnorm else nn.LayerNorm(cfg.d_model)

        # Support for multiple heads
        self.heads = nn.ModuleDict(heads)
        self.last_hidden: torch.Tensor | None = None

    def forward(
        self,
        x: torch.Tensor,                        # [B, T, A, F]
        bias: torch.Tensor | None = None        # [B or 1, H, T, T] (optional)
    ) -> torch.Tensor | dict[str, torch.Tensor]:
        B, T, A, F = x.shape
        assert A == self.n_assets and F == self.in_features, "Mismatch in asset/feature dims."

        h = x.reshape(B, T, A * F)              # flatten assets×features per time
        h = self.input_proj(h)                  # [B, T, d_model]
        if self.pos_emb is not None:
            h = h + self.pos_emb[:, :T, :]

        for blk in self.blocks:
            h = blk(h, bias=bias)

        h = self.norm_out(h)
        self.last_hidden = h

        # Compute outputs from each enabled head
        outs = {name: head(h) for name, head in self.heads.items()}

        # If only one head, return its tensor directly (for backward compat)
        if len(outs) == 1:
            return next(iter(outs.values()))
        return outs

    @staticmethod
    def build_from_config(cfg: dict, make_head: callable):
        """
        Factory: build ItoFormer + enabled heads based on YAML.
        make_head(name) -> nn.Module
        """
        io_cfg = ItoConfig(
            n_assets=cfg["model"].get("n_assets", 1),
            in_features=cfg["model"].get("in_features", cfg["data"].get("features_per_asset", 1)),
            d_model=cfg["model"]["encoder"]["d_model"],
            n_layers=cfg["model"]["encoder"]["n_layers"],
            n_heads=cfg["model"]["encoder"]["n_heads"],
            ff_mult=cfg["model"]["encoder"]["ff_mult"],
            attn_dropout=cfg["model"]["encoder"]["attn_dropout"],
            ffn_dropout=cfg["model"]["encoder"]["ffn_dropout"],
            resid_dropout=cfg["model"]["encoder"]["resid_dropout"],
            use_rmsnorm=cfg["model"]["encoder"]["use_rmsnorm"],
            use_bias=True,
            max_len=cfg["model"]["encoder"]["max_len"],
            pos_embed=cfg["model"]["encoder"]["pos_embed"],
        )

        enabled_heads = cfg["model"]["heads"]
        heads = {}
        for name, block in enabled_heads.items():
            if isinstance(block, dict) and block.get("enabled", False):
                h = make_head(name)
                if h is not None:
                    heads[name] = h

        return ItoFormer(io_cfg, heads)
