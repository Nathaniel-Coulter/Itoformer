# src/itoformer/models/heads/martingale.py
from __future__ import annotations
from typing import Optional

import torch
import torch.nn as nn

from itoformer.losses.martingale import martingale_drift_loss, girsanov_alignment_loss

class MartingaleHead(nn.Module):
    """
    Projects hidden states to discounted values \tilde S_t and
    provides convenience martingale/Girsanov penalties.

    Accepts [B,T,D] or [B,T,A,D]; returns [B,T,1] or [B,T,A,1] respectively.
    """
    def __init__(self, d_model: int, out_channels: int = 1):
        super().__init__()
        self.proj = nn.Linear(d_model, out_channels)

    def forward(self, h: torch.Tensor) -> torch.Tensor:
        if h.dim() == 3:
            # [B,T,D] -> [B,T,1]
            return self.proj(h)
        elif h.dim() == 4:
            # [B,T,A,D] -> [B,T,A,1]
            B,T,A,D = h.shape
            return self.proj(h)
        else:
            raise ValueError(f"MartingaleHead expected h [B,T,D] or [B,T,A,D], got {h.shape}")

    @staticmethod
    def loss_martingale(
        s_disc: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
        weight: float = 1.0,
    ) -> torch.Tensor:
        # squeeze last channel if singleton
        if s_disc.size(-1) == 1:
            s_disc = s_disc.squeeze(-1)
        return martingale_drift_loss(s_disc, mask=mask, weight=weight)

    @staticmethod
    def loss_girsanov(
        mu_hat: torch.Tensor,
        theta_hat: torch.Tensor,
        sigma_hat: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
        weight: float = 1.0,
    ) -> torch.Tensor:
        return girsanov_alignment_loss(mu_hat, theta_hat, sigma_hat, mask=mask, weight=weight)
