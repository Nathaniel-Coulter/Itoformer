import torch
import torch.nn as nn
from typing import Dict

class OptionsNodeHead(nn.Module):
    """
    Time-distributed projection head.
    Expects encoder features with shape:
      - [B, T, A, D] (we’ll use A=1) OR [B, T, D]
    Produces per-timestep outputs for each target:
      out[target] -> [B, T, 1]
    """
    def __init__(self, d_model: int, out_dims: Dict[str, int]):
        super().__init__()
        # one linear per target (1x1 over feature dim)
        self.proj = nn.ModuleDict({name: nn.Linear(d_model, dim) for name, dim in out_dims.items()})

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        # x: [B, T, A, D] or [B, T, D]
        if x.dim() == 4:
            # use the first (and only) asset axis
            x = x[:, :, 0, :]      # [B, T, D]
        assert x.dim() == 3, f"OptionsNodeHead expects [B,T,D], got {x.shape}"

        out = {}
        for name, layer in self.proj.items():
            y = layer(x)           # [B, T, out_dim]  (out_dim=1 for each target)
            out[name] = y          # keep last dim; our trainer handles squeeze/last step
        return out
