# src/itoformer/models/heads/forecast.py
from __future__ import annotations
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

class ForecastHead(nn.Module):
    """
    Maps hidden states to per-asset next-step returns.
    Accepts either:
      - [B, T, D]   -> [B, T, A]
      - [B, T, A, D]-> [B, T, A]
    Optionally outputs variance (Gaussian head) if out_var=True.
    """
    def __init__(self, d_model: int, n_assets: int, out_var: bool = False):
        super().__init__()
        self.n_assets = n_assets
        self.out_var = out_var

        self.proj_mean = nn.Linear(d_model, n_assets)
        if out_var:
            self.proj_logvar = nn.Linear(d_model, n_assets)

    def forward(self, h: torch.Tensor) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        """
        h: [B,T,D] or [B,T,A,D]
        returns:
          mean:    [B,T,A]
          logvar:  [B,T,A] or None
        """
        if h.dim() == 3:
            # [B,T,D] -> project to [B,T,A]
            mean = self.proj_mean(h)
            logvar = self.proj_logvar(h) if self.out_var else None
            return mean, logvar

        if h.dim() == 4:
            # [B,T,A,D] -> apply linear per asset
            B,T,A,D = h.shape
            h2 = h.reshape(B*T*A, D)
            mean = self.proj_mean(h2).reshape(B, T, A, self.n_assets)
            mean = mean[..., torch.arange(self.n_assets)]  # pick diagonal per-asset channel
            # If you want strict per-asset linear, create per-asset Linear or use a grouped 1x1 conv.
            # The above trick uses shared weights; we pick the first n_assets channels.
            if self.out_var:
                logvar = self.proj_logvar(h2).reshape(B, T, A, self.n_assets)
                logvar = logvar[..., torch.arange(self.n_assets)]
            else:
                logvar = None
            return mean, logvar

        raise ValueError(f"ForecastHead expected h with 3 or 4 dims, got {h.shape}")
