import torch
import torch.nn as nn

class TermStructureHead(nn.Module):
    """
    Reconstructs a vector of tenor yields from hidden state.
    """
    def __init__(self, d_model: int, n_tenors: int):
        super().__init__()
        self.readout = nn.Linear(d_model, n_tenors)
    def forward(self, h: torch.Tensor) -> torch.Tensor:
        if h.ndim == 3: h = h[:, -1, :]
        return self.readout(h)  # [B, n_tenors]
