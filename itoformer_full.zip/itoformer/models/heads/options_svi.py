# src/itoformer/models/heads/options_svi.py
# Complete SVI head + helpers (bounded parameterization, IV/surface utilities, and no-arb diagnostics)

from __future__ import annotations
from typing import Dict
import torch
import torch.nn as nn
import torch.nn.functional as F

EPS = 1e-12

# Default soft bounds (can be made YAML-driven later if you want tighter ranges per dataset)
DEFAULT_BOUNDS: Dict[str, tuple[float, float]] = {
    "a":     (0.0,   2.0),    # total variance intercept
    "b":     (0.0,  20.0),    # slope (>=0 for no-arb)
    "rho":   (-0.999, 0.999), # correlation-like, |rho| < 1
    "m":     (-3.0,   3.0),   # center of smile in log-moneyness
    "sigma": (0.005,  3.0),   # smoothness
}

def _squash_to_(x: torch.Tensor, lo: float, hi: float) -> torch.Tensor:
    """Map R -> (lo, hi) smoothly using tanh."""
    u = 0.5 * (torch.tanh(x) + 1.0)          # in (0,1)
    return lo + (hi - lo) * u                # in (lo,hi)

class SVIHead(nn.Module):
    """
    Predicts {a, b, rho, m, sigma} with bounded parameterization.
    Input:  h  [B, d_model]  (or [B, L, d_model], we take the last step)
    Output: dict of tensors, each shape [B]
    """
    def __init__(self, d_model: int, bounds: Dict[str, tuple[float, float]] | None = None):
        super().__init__()
        self.proj = nn.Linear(d_model, 5)
        self.bounds = bounds or DEFAULT_BOUNDS

        self.a_lo, self.a_hi         = self.bounds["a"]
        self.b_lo, self.b_hi         = self.bounds["b"]
        self.rho_lo, self.rho_hi     = self.bounds["rho"]
        self.m_lo, self.m_hi         = self.bounds["m"]
        self.sigma_lo, self.sigma_hi = self.bounds["sigma"]

    def forward(self, h: torch.Tensor) -> Dict[str, torch.Tensor]:
        if h.ndim == 3:
            h = h[:, -1, :]  # last step
        a_raw, b_raw, rho_raw, m_raw, sigma_raw = self.proj(h).unbind(-1)

        # Smoothly squash into practical bounds
        a     = _squash_to_(a_raw,     self.a_lo,     self.a_hi)
        b     = _squash_to_(b_raw,     self.b_lo,     self.b_hi)
        rho   = _squash_to_(rho_raw,   self.rho_lo,   self.rho_hi)
        m     = _squash_to_(m_raw,     self.m_lo,     self.m_hi)
        sigma = _squash_to_(sigma_raw, self.sigma_lo, self.sigma_hi)

        # Optional hardeners (kept mild)
        sigma = sigma.clamp_min(1e-3)  # avoid numerics if trainer weight spikes
        b     = b.clamp_min(0.0)       # keep slope >= 0

        return {"a": a, "b": b, "rho": rho, "m": m, "sigma": sigma}


# -------------------------
# SVI surface & IV helpers
# -------------------------
def svi_total_variance(
    k: torch.Tensor,
    a: torch.Tensor,
    b: torch.Tensor,
    rho: torch.Tensor,
    m: torch.Tensor,
    sigma: torch.Tensor,
) -> torch.Tensor:
    """
    Raw SVI total variance parameterization:
      w(k) = a + b * ( rho*(k - m) + sqrt( (k - m)^2 + sigma^2 ) )
    Shapes broadcast; k is [N], params can be scalars or [B], etc.
    """
    t = k - m
    return a + b * (rho * t + torch.sqrt(t * t + sigma * sigma + EPS))


def svi_iv_from_params(
    k: torch.Tensor,
    dte_days: float | torch.Tensor,
    a: torch.Tensor,
    b: torch.Tensor,
    rho: torch.Tensor,
    m: torch.Tensor,
    sigma: torch.Tensor,
) -> torch.Tensor:
    """
    Implied vol from SVI params: sigma_imp(k,T) = sqrt( w(k) / T ).
    `dte_days` can be a float or tensor; T = max(dte_days/365, 1e-6).
    """
    if not isinstance(dte_days, torch.Tensor):
        T = torch.as_tensor(dte_days, dtype=k.dtype, device=k.device)
    else:
        T = dte_days.to(dtype=k.dtype, device=k.device)
    T = torch.clamp(T / 365.0, min=1e-6)
    w = svi_total_variance(k, a, b, rho, m, sigma)
    return torch.sqrt(torch.clamp(w / T, min=EPS))


# -------------------------
# No-arbitrage diagnostics
# -------------------------
def butterfly_penalty(k_sorted: torch.Tensor, w_sorted: torch.Tensor) -> torch.Tensor:
    """
    Convexity in k: discrete second difference of total variance must be >= 0.
    penalty = mean( relu( -Δ² w ) ).
    Requires k_sorted and corresponding w_sorted sorted by k ascending.
    """
    n = k_sorted.numel()
    if n < 3:
        return torch.zeros((), device=w_sorted.device, dtype=w_sorted.dtype)
    d1 = w_sorted[1:] - w_sorted[:-1]
    d2 = d1[1:] - d1[:-1]
    return torch.relu(-d2).mean()


def butterfly_violation_rate(k_sorted: torch.Tensor, w_sorted: torch.Tensor, eps: float = 0.0) -> torch.Tensor:
    """Fraction of points where discrete second diff < -eps."""
    n = k_sorted.numel()
    if n < 3:
        return torch.zeros((), device=w_sorted.device, dtype=w_sorted.dtype)
    d1 = w_sorted[1:] - w_sorted[:-1]
    d2 = d1[1:] - d1[:-1]
    return (d2 < -eps).float().mean()


def calendar_penalty(w_T_short: torch.Tensor, w_T_long: torch.Tensor) -> torch.Tensor:
    """
    Calendar (maturity) monotonicity on already-aligned k-grid:
      total variance must be non-decreasing in T (longer T >= shorter T).
    """
    K = min(w_T_short.shape[0], w_T_long.shape[0])
    if K == 0:
        return torch.zeros((), device=w_T_short.device, dtype=w_T_short.dtype)
    return torch.relu(w_T_short[:K] - w_T_long[:K]).mean()


def calendar_violation_rate(w_T_short: torch.Tensor, w_T_long: torch.Tensor, eps: float = 0.0) -> torch.Tensor:
    """Rate where short-T total variance exceeds long-T by more than eps, after alignment."""
    K = min(w_T_short.shape[0], w_T_long.shape[0])
    if K == 0:
        return torch.zeros((), device=w_T_short.device, dtype=w_T_short.dtype)
    return (w_T_short[:K] > w_T_long[:K] + eps).float().mean()
