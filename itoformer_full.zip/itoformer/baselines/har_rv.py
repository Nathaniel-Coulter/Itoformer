# src/itoformer/baselines/har_rv.py
# HAR model for realized vol / IV.
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
import numpy as np
import pandas as pd
import statsmodels.api as sm

def _rolling_mean(s: pd.Series, w: int) -> pd.Series:
    return s.rolling(window=w, min_periods=w).mean()

@dataclass
class HAR_RV:
    daily_lag: int = 1
    weekly_window: int = 5
    monthly_window: int = 22
    add_const: bool = True

    _res: Optional[sm.regression.linear_model.RegressionResultsWrapper] = None
    _target_col: str = ""
    _train_index: Optional[pd.DatetimeIndex] = None
    _last_design_row: Optional[pd.DataFrame] = None
    _delta: Optional[pd.Timedelta] = None  # spacing between last two observations

    def _design(self, y: pd.Series) -> pd.DataFrame:
        X = pd.DataFrame(
            {
                "rv_d": y.shift(self.daily_lag),
                "rv_w": _rolling_mean(y, self.weekly_window).shift(1),
                "rv_m": _rolling_mean(y, self.monthly_window).shift(1),
            },
            index=y.index,
        )
        if self.add_const:
            X = sm.add_constant(X, has_constant="add")
        df = pd.concat([y.rename("y"), X], axis=1).dropna()
        return df

    def fit(self, df: pd.DataFrame, target_col: str) -> "HAR_RV":
        self._target_col = target_col
        y = df[target_col].astype("float64")
        self._train_index = pd.DatetimeIndex(df.index)
        if len(self._train_index) >= 2:
            self._delta = self._train_index[-1] - self._train_index[-2]
        design = self._design(y)
        self._res = sm.OLS(design["y"], design.drop(columns=["y"])).fit()
        # cache the last available design row for iterative forecasting
        self._last_design_row = design.drop(columns=["y"]).tail(1)
        return self

    def predict(self, h: int) -> pd.DataFrame:
        if self._res is None or self._last_design_row is None:
            raise RuntimeError("Call fit() before predict().")
        # One-step-ahead using last design row; for h>1, repeat last one-step (simple, stable)
        yhat1 = float(np.dot(self._last_design_row.values, self._res.params.values))
        yhat = np.repeat(yhat1, h)
        # produce a reasonable default index in case caller doesn't set it
        if self._train_index is not None and self._delta is not None:
            start = self._train_index[-1] + self._delta
            idx = pd.date_range(start=start, periods=h, freq=self._delta)
        else:
            idx = pd.RangeIndex(0, h)
        return pd.DataFrame({"yhat": yhat}, index=idx)
