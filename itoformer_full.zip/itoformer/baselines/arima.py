# src/itoformer/baselines/arima.py
# Minimal, robust ARIMA baseline with optional exogenous regressors.
# Depends: pandas, numpy, statsmodels

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple, Any
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

@dataclass
class ARIMABaseline:
    order: Tuple[int, int, int] = (1, 0, 1)
    seasonal_order: Tuple[int, int, int, int] = (0, 0, 0, 0)
    enforce_stationarity: bool = True
    enforce_invertibility: bool = True

    # Fitted state
    _model: Any = None
    _res: Any = None
    _target_col: str = ""
    _exog_cols: Optional[list[str]] = None

    def fit(
        self,
        train_df: pd.DataFrame,
        target_col: str,
        exog_cols: Optional[list[str]] = None,
        **kwargs,
    ) -> "ARIMABaseline":
        self._target_col = target_col
        self._exog_cols = exog_cols

        # y / X as float64
        y = train_df[target_col].astype("float64")
        X = train_df[exog_cols].astype("float64") if exog_cols else None

        self._model = ARIMA(
            endog=y,
            exog=X,
            order=self.order,
            seasonal_order=self.seasonal_order,
            enforce_stationarity=self.enforce_stationarity,
            enforce_invertibility=self.enforce_invertibility,
            **kwargs,
        )

        # Be compatible across statsmodels versions: don’t pass maxiter directly.
        # Try a couple of optimizers without extra kwargs.
        try:
            self._res = self._model.fit(method="lbfgs", disp=False)
        except Exception:
            try:
                self._res = self._model.fit(method="nm", disp=False)
            except Exception:
                # Fall back to defaults
                self._res = self._model.fit()

        return self

    def predict(
        self,
        h: int,
        X_future: Optional[pd.DataFrame] = None,
        return_conf_int: bool = False,
        alpha: float = 0.05,
    ) -> pd.DataFrame:
        if self._res is None:
            raise RuntimeError("Call fit() before predict().")

        if self._exog_cols:
            if X_future is None:
                raise ValueError("X_future must be provided for ARIMA with exogenous variables.")
            exog_fc = X_future[self._exog_cols].astype("float64")
        else:
            exog_fc = None

        fc = self._res.get_forecast(steps=h, exog=exog_fc)
        out = pd.DataFrame({"yhat": fc.predicted_mean})
        if return_conf_int:
            ci = fc.conf_int(alpha=alpha)
            ci.columns = ["lower", "upper"]
            out = out.join(ci)
        return out

    def walk_forward(
        self,
        df: pd.DataFrame,
        target_col: str,
        exog_cols: Optional[list[str]] = None,
        train_window: int = 252,
        test_h: int = 1,
        step: int = 1,
        **fit_kwargs,
    ) -> pd.DataFrame:
        """
        Rolling-origin evaluation:
        - train on [i-train_window, i)
        - forecast next 'test_h' steps at i
        """
        preds = []
        dates = df.index
        for i in range(train_window, len(df) - test_h + 1, step):
            train = df.iloc[i - train_window : i]
            test_idx = dates[i : i + test_h]
            self.fit(train, target_col, exog_cols, **fit_kwargs)
            X_future = df.loc[test_idx, exog_cols] if exog_cols else None
            fc = self.predict(test_h, X_future=X_future)
            fc.index = test_idx
            preds.append(fc)
        return pd.concat(preds).sort_index()
