# src/itoformer/baselines/garch.py
# Univariate GARCH(1,1) on returns or log-returns using 'arch' package.
# Predicts conditional variance; returns optional variance-to-vol mapping.
# Depends: pandas, numpy, arch>=5

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Literal
import numpy as np
import pandas as pd
from arch import arch_model

@dataclass
class GARCH11:
    dist: Literal["normal", "t", "skewt"] = "normal"
    mean: Literal["Zero", "Constant", "AR"] = "Zero"
    p: int = 1
    q: int = 1

    _res: Optional[any] = None
    _target_col: str = ""

    def fit(self, df: pd.DataFrame, target_col: str) -> "GARCH11":
        self._target_col = target_col
        y = df[target_col].astype("float64").dropna()
        am = arch_model(y, vol="GARCH", p=self.p, q=self.q, mean=self.mean, dist=self.dist)
        self._res = am.fit(disp="off")
        return self

    def predict(self, h: int, variance: bool = True) -> pd.DataFrame:
        if self._res is None:
            raise RuntimeError("Call fit() before predict().")
        fc = self._res.forecast(horizon=h, reindex=False)
        # variance forecast at horizons 1..h
        var = fc.variance.values[-1]
        out = pd.DataFrame({"var": var})
        if not variance:
            out["vol"] = np.sqrt(out["var"])
        return out

    def walk_forward(
        self,
        df: pd.DataFrame,
        target_col: str,
        train_window: int = 252,
        test_h: int = 1,
        step: int = 1,
        variance: bool = True,
    ) -> pd.DataFrame:
        preds = []
        dates = df.index
        for i in range(train_window, len(df) - test_h + 1, step):
            train = df.iloc[i - train_window : i]
            self.fit(train, target_col)
            fc = self.predict(test_h, variance=variance)
            fc.index = dates[i : i + test_h]
            preds.append(fc)
        return pd.concat(preds).sort_index()
