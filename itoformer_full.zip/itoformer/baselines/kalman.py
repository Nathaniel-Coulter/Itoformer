# src/itoformer/baselines/kalman.py
# Simple state-space baselines via statsmodels: Local Level, or AR(1) state.
# Useful for latent drift/vol factors or yield levels.
# Depends: pandas, numpy, statsmodels>=0.13

from __future__ import annotations
from dataclasses import dataclass
from typing import Literal, Optional
import numpy as np
import pandas as pd
import statsmodels.api as sm

@dataclass
class KalmanBaseline:
    model: Literal["local_level", "local_linear_trend", "ar1"] = "local_level"
    # storage
    _res: Optional[any] = None
    _endog_name: str = ""

    def _build(self, y: pd.Series):
        if self.model == "local_level":
            return sm.tsa.UnobservedComponents(y, level="llevel")
        if self.model == "local_linear_trend":
            return sm.tsa.UnobservedComponents(y, level="llevel", trend=True)
        if self.model == "ar1":
            # AR(1) state-space via SARIMAX(1,0,0)
            return sm.tsa.SARIMAX(y, order=(1, 0, 0), trend="c")
        raise ValueError(f"Unknown model: {self.model}")

    def fit(self, df: pd.DataFrame, target_col: str, **fit_kwargs) -> "KalmanBaseline":
        self._endog_name = target_col
        y = df[target_col].astype("float64").dropna()
        mod = self._build(y)
        self._res = mod.fit(disp=False, **fit_kwargs)
        return self

    def predict(self, h: int) -> pd.DataFrame:
        if self._res is None:
            raise RuntimeError("Call fit() before predict().")
        start = self._res.nobs
        end = self._res.nobs + h - 1
        yhat = self._res.get_prediction(start=start, end=end)
        out = pd.DataFrame({"yhat": yhat.predicted_mean})
        return out

    def walk_forward(
        self,
        df: pd.DataFrame,
        target_col: str,
        train_window: int = 252,
        test_h: int = 1,
        step: int = 1,
        **fit_kwargs,
    ) -> pd.DataFrame:
        preds = []
        dates = df.index
        for i in range(train_window, len(df) - test_h + 1, step):
            train = df.iloc[i - train_window : i]
            self.fit(train, target_col, **fit_kwargs)
            fc = self.predict(test_h)
            fc.index = dates[i : i + test_h]
            preds.append(fc)
        return pd.concat(preds).sort_index()
