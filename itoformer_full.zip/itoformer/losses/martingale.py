# src/itoformer/losses/martingale.py
from __future__ import annotations
from typing import Optional

import torch


def martingale_drift_loss(
    s_disc: torch.Tensor,
    mask: Optional[torch.Tensor] = None,
    reduction: str = "mean",
    weight: float = 1.0,
) -> torch.Tensor:
    """
    Penalize non-zero *average* discounted increment:
      L = mean_t ( E[ ΔS~_t ] )^2
    s_disc: [B, T, A] or [B, T] discounted predictions
    mask  : optional same shape mask
    """
    if s_disc.dim() == 2:
        dS = torch.zeros_like(s_disc)
        dS[:, 1:] = s_disc[:, 1:] - s_disc[:, :-1]
    elif s_disc.dim() == 3:
        dS = torch.zeros_like(s_disc)
        dS[:, 1:, :] = s_disc[:, 1:, :] - s_disc[:, :-1, :]
    else:
        raise ValueError(f"s_disc must be [B,T,(A)], got {s_disc.shape}")

    if mask is not None:
        dS = dS * mask

    # Average over batch/assets -> per-time mean increment
    if dS.dim() == 2:
        mean_t = dS.mean(dim=0)  # [T]
    else:
        mean_t = dS.mean(dim=(0, 2))  # [T]

    loss_vec = mean_t**2  # [T]
    if reduction == "mean":
        loss = weight * loss_vec.mean()
    elif reduction == "sum":
        loss = weight * loss_vec.sum()
    elif reduction == "none":
        loss = weight * loss_vec
    else:
        raise ValueError("reduction must be {'mean','sum','none'}")
    return loss


def girsanov_alignment_loss(
    mu_hat: torch.Tensor,
    theta_hat: torch.Tensor,
    sigma_hat: torch.Tensor,
    mask: Optional[torch.Tensor] = None,
    reduction: str = "mean",
    weight: float = 1.0,
) -> torch.Tensor:
    """
    Encourage μ̂ ≈ θ̂ σ̂ (drift neutralization under the learned Q).
    All tensors broadcastable to [B, T, A] or [B, T].
    """
    resid = mu_hat - theta_hat * sigma_hat
    if mask is not None:
        resid = resid * mask
    loss = resid**2
    if reduction == "mean":
        denom = (mask.sum() if (mask is not None) else loss.numel())
        loss = weight * loss.sum() / (denom + 1e-12)
    elif reduction == "sum":
        loss = weight * loss.sum()
    elif reduction == "none":
        loss = weight * loss
    else:
        raise ValueError("reduction must be {'mean','sum','none'}")
    return loss
