import torch

def butterfly_convexity_loss(surface: torch.Tensor) -> torch.Tensor:
    """
    surface: [B, N_k] IVs along strikes for a fixed maturity.
    Penalize negative second differences (convexity).
    """
    if surface.ndim == 3:  # [B, T, N_k]
        surface = surface[:, -1, :]
    d2 = surface[:, :-2] - 2*surface[:, 1:-1] + surface[:, 2:]
    viol = torch.relu(-d2)
    return viol.mean()

def calendar_monotonicity_loss(term: torch.Tensor) -> torch.Tensor:
    """
    term: [B, N_T] IVs across maturities at fixed moneyness.
    Penalize decreasing term-structure (very rough).
    """
    if term.ndim == 3:  # [B, T, N_T]
        term = term[:, -1, :]
    diffs = term[:, 1:] - term[:, :-1]
    viol = torch.relu(-diffs)
    return viol.mean()

def hjm_drift_consistency_loss(forward_seq: torch.Tensor, vol_spec=None) -> torch.Tensor:
    """
    Placeholder: penalize large mean drift in forward rates sequence.
    forward_seq: [B, T, N_tenor]
    """
    drift = forward_seq[:, 1:, :] - forward_seq[:, :-1, :]
    return drift.mean(dim=(1,2)).abs().mean()
