# src/itoformer/losses/ito.py
from __future__ import annotations
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


def realized_qv(x: torch.Tensor, eps: float = 1e-12) -> torch.Tensor:
    """
    Simple realized quadratic variation per step:
      Δ[X]_t ≈ (X_t - X_{t-1})^2
    x: [B, T, A] or [B, T] time series
    returns Δ[X] with same shape (first step = 0)
    """
    if x.dim() == 2:
        dx = x[:, 1:] - x[:, :-1]
        pad = torch.zeros_like(dx[:, :1])
        return torch.cat([pad, dx**2 + eps], dim=1)
    elif x.dim() == 3:
        dx = x[:, 1:, :] - x[:, :-1, :]
        pad = torch.zeros_like(dx[:, :1, :])
        return torch.cat([pad, dx**2 + eps], dim=1)
    else:
        raise ValueError(f"expected x with 2 or 3 dims, got {x.shape}")


def ito_consistency_loss(
    f: torch.Tensor,
    f_x: torch.Tensor,
    f_xx: torch.Tensor,
    delta_x: torch.Tensor,
    delta_qv: torch.Tensor,
    mask: Optional[torch.Tensor] = None,
    reduction: str = "mean",
    weight: float = 1.0,
) -> torch.Tensor:
    """
    Enforce Itô's lemma on a scalar feature map f.

    Shapes (broadcastable):
      f:       [B, T, A] or [B, T]
      f_x:     same as f
      f_xx:    same as f
      delta_x: same as f
      delta_qv:same as f
      mask:    optional boolean/float mask same shape as f (True/1 = keep)

    Returns scalar loss (default) or per-element depending on reduction.
    """
    # Δf
    if f.dim() == 2:
        df = torch.zeros_like(f)
        df[:, 1:] = f[:, 1:] - f[:, :-1]
    elif f.dim() == 3:
        df = torch.zeros_like(f)
        df[:, 1:, :] = f[:, 1:, :] - f[:, :-1, :]
    else:
        raise ValueError(f"f must be [B,T,(A)], got {f.shape}")

    # Ito residual: Δf - f_x ΔX - 0.5 f_xx Δ[X]
    resid = df - (f_x * delta_x) - 0.5 * (f_xx * delta_qv)

    if mask is not None:
        resid = resid * mask

    loss = resid**2
    if reduction == "mean":
        denom = (mask.sum() if (mask is not None) else loss.numel())
        loss = weight * loss.sum() / (denom + 1e-12)
    elif reduction == "sum":
        loss = weight * loss.sum()
    elif reduction == "none":
        loss = weight * loss
    else:
        raise ValueError("reduction must be one of {'mean','sum','none'}")
    return loss
