from __future__ import annotations
import torch
from torch import nn
from typing import Optional

class CalendarDeltaTEmbedding(nn.Module):
    """
    Calendar features + √Δt embedding for Ito-aware time scaling.
    - day-of-week, month-of-year, event flags (optional)
    - Δt -> embed(√Δt) as an additive bias channel
    """
    def __init__(
        self,
        d_model: int,
        use_dow: bool = True,
        use_month: bool = True,
        n_events: int = 0,               # e.g., FOMC, CPI flags
    ):
        super().__init__()
        self.use_dow = use_dow
        self.use_month = use_month
        self.n_events = n_events

        self.dow_emb = nn.Embedding(7, d_model) if use_dow else None
        self.month_emb = nn.Embedding(12, d_model) if use_month else None
        self.event_proj = nn.Linear(n_events, d_model) if n_events > 0 else None
        self.sqrt_dt_proj = nn.Linear(1, d_model)

    def forward(
        self,
        dow: Optional[torch.Tensor],       # [B, T] ints in [0..6] or None
        month: Optional[torch.Tensor],     # [B, T] ints in [1..12] or None
        events: Optional[torch.Tensor],    # [B, T, n_events] float flags or None
        delta_t: torch.Tensor,             # [B, T] float in time units
    ) -> torch.Tensor:
        B, T = delta_t.shape
        feats = torch.zeros(B, T, self.sqrt_dt_proj.out_features, device=delta_t.device)

        if self.dow_emb is not None and dow is not None:
            feats = feats + self.dow_emb(dow)
        if self.month_emb is not None and month is not None:
            feats = feats + self.month_emb(month - 1)  # month in [1..12]
        if self.event_proj is not None and events is not None:
            feats = feats + self.event_proj(events)

        sqrt_dt = torch.sqrt(torch.clamp(delta_t, min=1e-12)).unsqueeze(-1)  # [B,T,1]
        feats = feats + self.sqrt_dt_proj(sqrt_dt)
        return feats
