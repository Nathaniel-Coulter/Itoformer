from __future__ import annotations
import torch
from torch import nn
from typing import Dict, Tuple

def _rolling_var(x: torch.Tensor, w: int) -> torch.Tensor:
    # x: [T], returns: [T], unbiased=False, overlap windows; no look-ahead if caller slices appropriately.
    if x.numel() < w:
        return torch.zeros_like(x)
    cumsum = torch.cumsum(x, 0)
    cumsum2 = torch.cumsum(x * x, 0)
    v = torch.empty_like(x)
    v[:w-1] = torch.nan
    n = w
    s = cumsum[w-1:] - torch.cat([torch.tensor([0.0], device=x.device), cumsum[:-w+1]])
    s2 = cumsum2[w-1:] - torch.cat([torch.tensor([0.0], device=x.device), cumsum2[:-w+1]])
    var = (s2 / n) - (s / n) ** 2
    v[w-1:] = var
    return v

def _rolling_cov(x: torch.Tensor, y: torch.Tensor, w: int) -> torch.Tensor:
    # x,y: [T]
    if x.numel() != y.numel():
        raise ValueError("x and y must have same length")
    if x.numel() < w:
        return torch.zeros_like(x)
    c1 = torch.cumsum(x, 0); c2 = torch.cumsum(y, 0); c12 = torch.cumsum(x*y, 0)
    out = torch.empty_like(x)
    out[:w-1] = torch.nan
    n = w
    s1 = c1[w-1:] - torch.cat([torch.tensor([0.0], device=x.device), c1[:-w+1]])
    s2 = c2[w-1:] - torch.cat([torch.tensor([0.0], device=x.device), c2[:-w+1]])
    s12 = c12[w-1:] - torch.cat([torch.tensor([0.0], device=x.device), c12[:-w+1]])
    cov = (s12 / n) - (s1 / n) * (s2 / n)
    out[w-1:] = cov
    return out

class ItoVolEncoder(nn.Module):
    """
    Leak-free estimators over [t-Δ, t]:
      - μ̂_t   : rolling mean of returns
      - σ̂²_t  : realized variance
      - [X]_t  : quadratic variation proxy (σ̂²_t * Δt or realized var)
      - [X_i,X_j]_t : realized covariation
      - Jump stats (optional): simple threshold counts / magnitudes
    """
    def __init__(self, window: int = 20, dt: float = 1.0, jump_z: float = 4.0):
        super().__init__()
        self.window = window
        self.dt = dt
        self.jump_z = jump_z

    def forward(self, R: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        R: returns panel [T, A] (e.g., log returns), NO look-ahead parts.
        Outputs are aligned so that each t uses only <= t data.
        """
        T, A = R.shape
        mu = torch.stack([torch.nanmean(R[max(0,t-self.window+1):t+1, :], dim=0) for t in range(T)], dim=0)
        sig2 = torch.stack([
            torch.nanmean((R[max(0,t-self.window+1):t+1, :] - mu[t:t+1, :])**2, dim=0)
            for t in range(T)
        ], dim=0)

        qv = sig2 * self.dt  # quadratic variation proxy per step
        # Pairwise realized covariation (optional, small A fine; for large A restrict to neighbors)
        cov_pairs = {}
        for i in range(A):
            for j in range(i, A):
                c = torch.tensor([
                    torch.nanmean(
                        (R[max(0,t-self.window+1):t+1, i] - mu[t, i]) *
                        (R[max(0,t-self.window+1):t+1, j] - mu[t, j])
                    )
                    for t in range(T)
                ], device=R.device)
                cov_pairs[(i, j)] = c
                if j != i:
                    cov_pairs[(j, i)] = c

        # Naive jump detector (z-score threshold)
        std = torch.sqrt(sig2 + 1e-12)
        z = torch.where(std > 0, (R - mu) / std, torch.zeros_like(R))
        jump_mask = (z.abs() >= self.jump_z).float()
        jump_count = torch.stack([
            jump_mask[max(0,t-self.window+1):t+1, :].sum(0) for t in range(T)
        ], dim=0)

        return {
            "mu": mu,                 # [T, A]
            "sig2": sig2,             # [T, A]
            "qv": qv,                 # [T, A]
            "cov_pairs": cov_pairs,   # dict[(i,j)] -> [T]
            "jump_count": jump_count, # [T, A]
        }
