from __future__ import annotations
import numpy as np
import torch
from torch import nn
from typing import Tuple, Optional

class StatFactorEncoder(nn.Module):
    """
    PCA / linear AE for panels & surfaces (retain ≥95% var)
    -------
    - Fit ONLY on in-sample windows to avoid look-ahead.
    - Returns latent factors + (optional) reconstruction.
    """
    def __init__(
        self,
        n_components: Optional[int] = None,
        var_threshold: float = 0.95,
        use_linear_ae: bool = False,
        ae_hidden: int = 64,
        ae_latent: int = 8,
    ):
        super().__init__()
        self.n_components = n_components
        self.var_threshold = var_threshold
        self.use_linear_ae = use_linear_ae
        self.register_buffer("mean_", None)
        self.register_buffer("components_", None)      # [feat, k]
        self.register_buffer("explained_var_ratio_", None)

        if use_linear_ae:
            self.encoder = nn.Sequential(nn.Linear(ae_hidden, ae_latent, bias=False))
            self.decoder = nn.Sequential(nn.Linear(ae_latent, ae_hidden, bias=False))
            # Note: caller maps features -> ae_hidden outside if needed.

    @torch.no_grad()
    def fit_pca(self, X: torch.Tensor):
        """
        X: [T, F] or [N, F] standardized (caller responsibility).
        """
        Xc = X - X.mean(0, keepdim=True)
        self.mean_ = X.mean(0, keepdim=True)
        # SVD economy
        U, S, Vt = torch.linalg.svd(Xc, full_matrices=False)  # Vt: [k, F]
        var = (S ** 2) / (X.shape[0] - 1)
        var_ratio = var / var.sum()
        if self.n_components is None:
            k = int((torch.cumsum(var_ratio, 0) <= self.var_threshold).sum().item() + 1)
        else:
            k = self.n_components
        self.components_ = Vt[:k].T.contiguous()  # [F, k]
        self.explained_var_ratio_ = var_ratio[:k]

    def forward(self, X: torch.Tensor) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        """
        X: [B, T, F] or [T, F]
        Returns:
          Z: [B, T, k] latent factors
          X_hat (optional): reconstruction if PCA available
        """
        orig_shape = X.shape
        if X.dim() == 3:
            B, T, F = X.shape
            X2 = X.reshape(B * T, F)
        else:
            B, T, F = 1, X.shape[0], X.shape[1]
            X2 = X

        if self.use_linear_ae:
            Z = self.encoder(X2)
            X_hat = self.decoder(Z)
            Z = Z.reshape(B, T, -1)
            X_hat = X_hat.reshape(B, T, -1)
            return Z, X_hat

        # PCA path (requires fit_pca first)
        if self.components_ is None:
            raise RuntimeError("StatFactorEncoder: call fit_pca() on in-sample window before forward().")
        Xc = X2 - self.mean_
        Z = Xc @ self.components_  # [*, k]
        X_hat = Z @ self.components_.T + self.mean_
        Z = Z.reshape(B, T, -1)
        X_hat = X_hat.reshape(B, T, F)
        return Z, X_hat
