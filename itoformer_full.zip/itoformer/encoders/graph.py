from __future__ import annotations
import numpy as np
import torch
from typing import Optional

class GraphEncoder:
    """
    Builds an adjacency / bias matrix for attention from sector/factor/curve links.
    - Input can be sector labels or a correlation matrix.
    - Output: adjacency [A, A] and/or bias matrix B_graph [A, A].
    """

    def __init__(self, corr_to_bias_scale: float = 0.5, same_sector_bonus: float = 0.2):
        self.corr_to_bias_scale = corr_to_bias_scale
        self.same_sector_bonus = same_sector_bonus

    def from_sectors(self, sectors: list[str]) -> torch.Tensor:
        A = len(sectors)
        adj = torch.zeros(A, A)
        for i in range(A):
            for j in range(A):
                if sectors[i] == sectors[j]:
                    adj[i, j] = 1.0
        return adj

    def from_corr(self, corr: np.ndarray) -> torch.Tensor:
        # corr: [A, A] in [-1,1]
        return torch.from_numpy(corr).float()

    def bias_matrix(
        self,
        sectors: Optional[list[str]] = None,
        corr: Optional[np.ndarray] = None
    ) -> torch.Tensor:
        """
        Returns B_graph [A, A] to add to attention logits.
        """
        if corr is None and sectors is None:
            raise ValueError("Provide either sectors or corr.")
        if corr is not None:
            B = torch.from_numpy(corr).float() * self.corr_to_bias_scale
        else:
            A = len(sectors)
            B = torch.zeros(A, A)
            for i in range(A):
                for j in range(A):
                    if sectors[i] == sectors[j]:
                        B[i, j] = self.same_sector_bonus
        return B
