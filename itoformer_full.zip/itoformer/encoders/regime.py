from __future__ import annotations
import numpy as np
import torch
from typing import Dict

class RegimeEncoder:
    """
    Simple, fast regime IDs:
      - Volatility buckets from rolling σ̂
      - Optional k-means over [μ̂, σ̂] to get discrete regimes
    Assumes caller supplies μ̂, σ̂ (e.g., from ItoVolEncoder).
    """

    def __init__(self, n_buckets: int = 4, use_kmeans: bool = False, k: int = 3, seed: int = 0):
        self.n_buckets = n_buckets
        self.use_kmeans = use_kmeans
        self.k = k
        self.rng = np.random.RandomState(seed)
        self.kmeans_centers = None  # set during fit

    def fit_kmeans(self, feats: np.ndarray, iters: int = 50):
        """
        feats: [T, D] (e.g., D=2 using [mu, sigma])
        """
        T, D = feats.shape
        centers = feats[self.rng.choice(T, self.k, replace=False)]
        for _ in range(iters):
            d = ((feats[:, None, :] - centers[None, :, :]) ** 2).sum(-1)
            assign = d.argmin(1)
            for j in range(self.k):
                mask = assign == j
                if mask.any():
                    centers[j] = feats[mask].mean(0)
        self.kmeans_centers = centers

    def transform(self, feats: np.ndarray) -> Dict[str, np.ndarray]:
        """
        Returns:
          bucket_id: vol buckets [T]
          regime_id: kmeans cluster IDs (if enabled) [T]
        """
        # Vol buckets on last column assumed sigma
        sigma = feats[:, -1]
        edges = np.quantile(sigma[~np.isnan(sigma)], np.linspace(0, 1, self.n_buckets + 1))
        bucket_id = np.digitize(sigma, edges[1:-1], right=True)

        regime_id = None
        if self.use_kmeans and self.kmeans_centers is not None:
            d = ((feats[:, None, :] - self.kmeans_centers[None, :, :]) ** 2).sum(-1)
            regime_id = d.argmin(1)
        return {"bucket_id": bucket_id, "regime_id": regime_id}
