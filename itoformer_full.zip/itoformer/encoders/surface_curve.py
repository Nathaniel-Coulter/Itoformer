from __future__ import annotations
import torch
from torch import nn
from typing import Tuple, Optional

class SurfaceCurveEncoder(nn.Module):
    """
    Encodes a 2D surface (e.g., vol surface or yield curve samples) into a compact latent.
    Two modes:
      - PCA-like linear compression via 1x1 conv (fast)
      - Small deep AE for nonlinearity (appendix-ready)
    Input: X [B, T, R, C]  -> e.g., rows=moneyness or maturities, cols=expiries or curve tenors
    """
    def __init__(self, rows: int, cols: int, latent_dim: int = 8, use_deep_ae: bool = False):
        super().__init__()
        self.rows, self.cols, self.latent_dim = rows, cols, latent_dim
        self.use_deep_ae = use_deep_ae

        if use_deep_ae:
            D = rows * cols
            self.enc = nn.Sequential(
                nn.Linear(D, 64), nn.ReLU(),
                nn.Linear(64, latent_dim)
            )
            self.dec = nn.Sequential(
                nn.Linear(latent_dim, 64), nn.ReLU(),
                nn.Linear(64, D)
            )
        else:
            # Linear bottleneck as “PCA-ish” encoder
            self.enc = nn.Sequential(nn.Flatten(start_dim=2), nn.Linear(rows * cols, latent_dim, bias=False))
            self.dec = nn.Sequential(nn.Linear(latent_dim, rows * cols, bias=False))

    def forward(self, X: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        X: [B, T, R, C]
        Returns:
          Z: [B, T, latent_dim]
          X_hat: [B, T, R, C]
        """
        B, T, R, C = X.shape
        Z = self.enc(X)                       # [B, T, latent]
        X_hat = self.dec(Z).reshape(B, T, R, C)
        return Z, X_hat
