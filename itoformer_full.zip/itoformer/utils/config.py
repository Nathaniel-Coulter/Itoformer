from __future__ import annotations
import os
from omegaconf import OmegaConf

def load_config(path: str) -> dict:
    cfg = OmegaConf.load(path)
    # Resolve ${...} interpolations
    cfg = OmegaConf.to_container(cfg, resolve=True)
    # Environment expansion pass (optional)
    def _expand(x):
        return os.path.expandvars(x) if isinstance(x, str) else x
    def _walk(d):
        if isinstance(d, dict):
            return {k: _walk(v) for k, v in d.items()}
        if isinstance(d, list):
            return [_walk(v) for v in d]
        return _expand(d)
    return _walk(cfg)
