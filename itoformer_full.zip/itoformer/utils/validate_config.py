import argparse
import os
import sys
import yaml
from typing import Any, Dict, List, Tuple

# Optional: support OmegaConf-style ${...} interpolation if available.
def load_and_resolve_yaml(path: str) -> Dict[str, Any]:
    try:
        from omegaconf import OmegaConf
        cfg = OmegaConf.load(path)
        # Resolve ${...} -> strings
        return OmegaConf.to_container(cfg, resolve=True)  # type: ignore
    except Exception:
        # Fallback: plain YAML + simple ${paths.*} substitution using a shallow resolver
        with open(path, "r") as f:
            cfg = yaml.safe_load(f)
        return _simple_interpolate(cfg)

def _simple_interpolate(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Minimal ${paths.*} interpolation so you can run without OmegaConf.
    Only resolves strings; nested dict lookups limited to 'paths.*'.
    """
    def resolve_string(s: str) -> str:
        if not isinstance(s, str):
            return s
        out = s
        # Resolve environment variables first
        out = os.path.expandvars(out)
        # Resolve ${paths.xxx}
        paths = cfg.get("paths", {})
        if isinstance(paths, dict):
            for k, v in paths.items():
                if isinstance(v, str):
                    out = out.replace("${paths.%s}" % k, v)
        return out

    def walk(x):
        if isinstance(x, dict):
            return {k: walk(v) for k, v in x.items()}
        elif isinstance(x, list):
            return [walk(v) for v in x]
        elif isinstance(x, str):
            return resolve_string(x)
        return x

    # one pass to ensure paths.* are available
    cfg = walk(cfg)
    # second pass allows chained paths like ${paths.data_root} inside lists, etc.
    cfg = walk(cfg)
    return cfg

def _csv_head(path: str) -> Tuple[List[str], str]:
    """Return header columns and an error string ('' if OK)."""
    import pandas as pd
    try:
        df = pd.read_csv(path, nrows=1)
        return df.columns.tolist(), ""
    except Exception as e:
        return [], f"Failed to read {path}: {e}"

def _missing(required: List[str], available: List[str]) -> List[str]:
    req_set = [r for r in required if r is not None]
    return [r for r in req_set if r not in available]

def _ok(msg: str):
    print(f"✅ {msg}")

def _warn(msg: str):
    print(f"⚠️  {msg}")

def _err(msg: str):
    print(f"❌ {msg}")

# ------------------------ Validators per data.source -------------------------

def validate_equities(cfg: Dict[str, Any]) -> int:
    errors = 0
    data = cfg.get("data", {})
    files: Dict[str, str] = data.get("files", {})
    schema = data.get("schema", {})
    date_col = schema.get("date_col", "Date")
    price_col = schema.get("price_col", "Adj Close")

    if not files:
        _err("equities.files is empty.")
        return 1

    for sym, fpath in files.items():
        if not os.path.exists(fpath):
            _err(f"[equities] Missing file for {sym}: {fpath}")
            errors += 1
            continue
        cols, e = _csv_head(fpath)
        if e:
            _err(e); errors += 1; continue
        missing = _missing([date_col, price_col], cols)
        if missing:
            _err(f"[equities] {sym}: missing columns {missing} in {fpath}. Found: {cols}")
            errors += 1
        else:
            _ok(f"[equities] {sym} OK ({date_col}, {price_col})")

    return errors

def validate_options_nodes(cfg: Dict[str, Any]) -> int:
    errors = 0
    data = cfg.get("data", {})
    files = data.get("files", {})
    chain = files.get("chain")
    aux = files.get("aux", {})
    schema = data.get("schema", {})

    req_chain_cols = [
        schema.get("date_col", "date"),
        schema.get("exp_col", "expiration"),
        schema.get("dte_col", "dte"),
        schema.get("cp_col", "call_put"),
        schema.get("strike_col", "strike"),
        schema.get("iv_col", "iv"),
        schema.get("delta_col", "delta"),
        schema.get("gamma_col", "gamma"),
        schema.get("vega_col", "vega"),
        schema.get("theta_col", "theta"),
    ]

    # Chain file
    if not chain or not os.path.exists(chain):
        _err(f"[options_nodes] Missing chain file: {chain}")
        errors += 1
    else:
        cols, e = _csv_head(chain)
        if e:
            _err(e); errors += 1
        else:
            miss = _missing(req_chain_cols, cols)
            if miss:
                _err(f"[options_nodes] chain missing columns {miss} in {chain}. Found: {cols}")
                errors += 1
            else:
                _ok(f"[options_nodes] chain OK columns in {os.path.basename(chain)}")

    # Aux files are optional; just confirm their presence if configured
    for key, fpath in aux.items():
        if fpath is None:
            continue
        if not os.path.exists(fpath):
            _warn(f"[options_nodes] aux {key}: file not found: {fpath}")
        else:
            _ok(f"[options_nodes] aux {key}: {os.path.basename(fpath)}")

    return errors

def validate_options_svi(cfg: Dict[str, Any]) -> int:
    errors = 0
    data = cfg.get("data", {})
    files = data.get("files", {})
    chain = files.get("chain")
    aux = files.get("aux", {})
    schema = data.get("schema", {})

    req_chain_cols = [
        schema.get("date_col", "date"),
        schema.get("exp_col", "expiration"),
        schema.get("dte_col", "dte"),
        schema.get("cp_col", "call_put"),
        schema.get("strike_col", "strike"),
        schema.get("iv_col", "iv"),
    ]

    if not chain or not os.path.exists(chain):
        _err(f"[options_svi] Missing chain file: {chain}")
        errors += 1
    else:
        cols, e = _csv_head(chain)
        if e:
            _err(e); errors += 1
        else:
            miss = _missing(req_chain_cols, cols)
            if miss:
                _err(f"[options_svi] chain missing columns {miss} in {chain}. Found: {cols}")
                errors += 1
            else:
                _ok(f"[options_svi] chain OK columns in {os.path.basename(chain)}")

    # Aux files optional
    for key, fpath in aux.items():
        if fpath is None:
            continue
        if not os.path.exists(fpath):
            _warn(f"[options_svi] aux {key}: file not found: {fpath}")
        else:
            _ok(f"[options_svi] aux {key}: {os.path.basename(fpath)}")

    # Sanity: parameterization spelling
    svi = data.get("svi", {})
    paramz = svi.get("parameterization", "bounded")
    if paramz not in ("bounded", "raw"):
        _warn(f"[options_svi] svi.parameterization is '{paramz}', expected 'bounded'|'raw'.")

    return errors

def validate_rates(cfg: Dict[str, Any]) -> int:
    errors = 0
    data = cfg.get("data", {})
    files = data.get("files", {})
    schema = data.get("schema", {})
    fred = schema.get("fred", {})
    panel = schema.get("panel", {})
    fred_date = fred.get("date_col", "observation_date")
    fred_overrides: Dict[str, str] = fred.get("overrides", {})

    # Validate presence of files
    def check_file(path: str, label: str):
        nonlocal errors
        if not os.path.exists(path):
            _err(f"[rates] Missing {label} file: {path}")
            errors += 1
            return None, []
        cols, e = _csv_head(path)
        if e:
            _err(e); errors += 1; return None, []
        return path, cols

    # Iterate nested maps (ust_yields, tips, breakevens, credit, macro, panels)
    for group, mapping in files.items():
        if not isinstance(mapping, dict):
            continue
        for name, path in mapping.items():
            p, cols = check_file(path, f"{group}.{name}")
            if p is None:
                continue

            base = os.path.basename(path)
            # FRED-style (2 cols) or panel-style?
            if group != "panels":
                # FRED-style: require date col + one data col
                if fred_date not in cols:
                    _err(f"[rates] {group}.{name}: missing date col '{fred_date}' in {path}. Found: {cols}")
                    errors += 1
                    continue
                # find value column
                val = fred_overrides.get(base)
                if val is None:
                    # Heuristic: take "the other" column if exactly 2 columns
                    if len(cols) >= 2:
                        # prefer a column that equals series name if present
                        candidates = [c for c in cols if c != fred_date]
                        val = candidates[0] if candidates else None
                if val and val not in cols:
                    _err(f"[rates] {group}.{name}: override '{val}' not found in {path}. Found: {cols}")
                    errors += 1
                else:
                    _ok(f"[rates] {group}.{name} OK ({fred_date} + {val or 'auto-detect'})")
            else:
                # panel-style: obey schema.panel shapes if provided
                panel_schema = panel.get(name, {})
                date_col = panel_schema.get("date_col", "Date")
                tenor_cols = panel_schema.get("tenor_cols")
                value_cols = panel_schema.get("value_cols")

                if date_col not in cols:
                    _err(f"[rates] panels.{name}: missing date col '{date_col}' in {path}. Found: {cols}")
                    errors += 1
                    continue

                if tenor_cols:
                    missing = _missing(tenor_cols, cols)
                    if missing:
                        _err(f"[rates] panels.{name}: missing tenor cols {missing} in {path}.")
                        errors += 1
                    else:
                        _ok(f"[rates] panels.{name} OK ({date_col} + listed tenor_cols)")
                elif value_cols:
                    missing = _missing(value_cols, cols)
                    if missing:
                        _err(f"[rates] panels.{name}: missing value cols {missing} in {path}.")
                        errors += 1
                    else:
                        _ok(f"[rates] panels.{name} OK ({date_col} + listed value_cols)")
                else:
                    # If no explicit cols, accept all numeric after date_col
                    _ok(f"[rates] panels.{name} OK ({date_col} + auto-detected numeric cols)")

    return errors

# ---------------------------------------------------------------------------

def validate(cfg_path: str) -> int:
    cfg = load_and_resolve_yaml(cfg_path)
    source = (cfg.get("data", {}) or {}).get("source")

    if not source:
        _err("Config missing data.source key.")
        return 1

    print(f"=== Validating: {cfg_path} | source={source} ===")
    # Check common paths exist
    for key in ["project_root", "outputs_root"]:
        p = cfg.get("paths", {}).get(key)
        if p and not os.path.isdir(p):
            _warn(f"paths.{key} does not exist yet: {p}")

    if source == "equities":
        return validate_equities(cfg)
    elif source == "options_nodes":
        return validate_options_nodes(cfg)
    elif source == "options_svi":
        return validate_options_svi(cfg)
    elif source == "rates":
        return validate_rates(cfg)
    else:
        _warn(f"Unknown data.source='{source}'. No specific validation run.")
        return 0

def main():
    ap = argparse.ArgumentParser(description="Validate YAML config paths and CSV schemas.")
    ap.add_argument("configs", nargs="+", help="Path(s) to YAML config(s)")
    args = ap.parse_args()

    total_errors = 0
    for cfg_path in args.configs:
        rc = validate(cfg_path)
        if rc == 0:
            _ok(f"{cfg_path} ✅ OK")
        else:
            _err(f"{cfg_path} ❌ {rc} error(s)")
        total_errors += rc

    if total_errors > 0:
        sys.exit(1)

if __name__ == "__main__":
    main()
