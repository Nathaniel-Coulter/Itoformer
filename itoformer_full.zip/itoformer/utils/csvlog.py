# src/itoformer/utils/csvlog.py
from __future__ import annotations
import csv, os, time
from typing import Sequence, Mapping, Any

def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)

def append_row(csv_path: str, header: Sequence[str], row: Mapping[str, Any]) -> None:
    """Append a row with stable header (create file & header on first write)."""
    ensure_dir(os.path.dirname(csv_path))
    write_header = not os.path.exists(csv_path)
    with open(csv_path, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(header))
        if write_header:
            w.writeheader()
        # coerce missing keys to blanks so DictWriter never crashes
        safe = {k: row.get(k, "") for k in header}
        w.writerow(safe)

class Stopwatch:
    def __init__(self) -> None:
        self.t0 = time.perf_counter()
    def seconds(self) -> float:
        return time.perf_counter() - self.t0
