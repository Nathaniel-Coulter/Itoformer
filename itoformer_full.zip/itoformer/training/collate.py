# src/itoformer/training/collate.py
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple, Union, Optional, Dict

import torch
import torch.nn as nn

Sample = Union[
    Tuple[torch.Tensor, torch.Tensor],                        # (x, y)
    Tuple[torch.Tensor, torch.Tensor, Dict[str, torch.Tensor]],  # (x, y, meta)
    Dict[str, torch.Tensor],                                  # {"x":..., "y":..., "...": ...}
]

@dataclass
class BiasConfig:
    """Configuration for optional attention-bias construction."""
    enable_time_decay: bool = True
    enable_corr_prior: bool = True
    # Time-decay: B_time[i,j] = -lambda * max(0, t_i - t_j)
    lambda_time: float = 0.05
    # Corr prior strength (applied to cosine-similarity between time slices):
    gamma_corr: float = 0.5
    # Similarity mode for corr prior: "cosine" (stable) or "dot"
    corr_mode: str = "cosine"
    # Put biases on all heads (broadcast). n_heads used only for shape.
    n_heads: int = 8
    # If True, return bias with batch dimension 1 (shared across batch);
    # else compute per-batch example (costlier). Shared is usually fine.
    share_across_batch: bool = True

class CollateBuilder:
    """
    Collate that stacks samples into a batch and (optionally) builds
    additive attention-bias tensors of shape [B or 1, H, T, T].

    Expected sample formats:
      (x, y) or (x, y, meta) or {"x":..., "y":..., "timestamps":...}
    Where:
      x: [T, A, F]
      y: [T, A]
      timestamps (optional): [T] datetime64 or float Δt; if absent, Δt=1.
    """
    def __init__(self, bias_cfg: Optional[BiasConfig] = None, device: Optional[torch.device] = None):
        self.bias_cfg = bias_cfg or BiasConfig()
        self.device = device

    def __call__(self, samples: List[Sample]):
        # ---- normalize input shapes ----
        xs, ys, ts_list = [], [], []

        for s in samples:
            if isinstance(s, dict):
                x = s["x"]
                y = s["y"]
                t = s.get("timestamps", None)
            elif isinstance(s, tuple):
                if len(s) == 2:
                    x, y = s
                    t = None
                elif len(s) == 3:
                    x, y, meta = s
                    # meta may have "timestamps"
                    if isinstance(meta, dict):
                        t = meta.get("timestamps", None)
                    else:
                        t = None
                else:
                    raise ValueError("Sample tuple must be (x,y) or (x,y,meta).")
            else:
                raise ValueError("Unsupported sample type.")

            # Ensure shapes are T x A x F and T x A
            assert x.dim() == 3, f"x must be [T,A,F], got {x.shape}"
            assert y.dim() == 2, f"y must be [T,A], got {y.shape}"

            xs.append(x)
            ys.append(y)
            ts_list.append(t)

        # Stack into batch
        x = torch.stack(xs, dim=0)  # [B,T,A,F]
        y = torch.stack(ys, dim=0)  # [B,T,A]

        # Move to device (if provided)
        if self.device is not None:
            x = x.to(self.device, non_blocking=True)
            y = y.to(self.device, non_blocking=True)

        # ---- optional bias construction ----
        bias = self._build_bias(x, ts_list) if (self.bias_cfg is not None) else None

        if bias is None:
            return x, y
        else:
            return x, y, bias

    # ---------------- internal: bias builders ---------------- #

    def _build_bias(self, x: torch.Tensor, ts_list: List[Optional[torch.Tensor]]) -> Optional[torch.Tensor]:
        """
        Build additive bias tensor of shape [B or 1, H, T, T].
        We construct each component and sum:
          B_total = B_time + B_corr   (components may be disabled)
        """
        B, T, A, F = x.shape
        H = self.bias_cfg.n_heads
        device = x.device

        components = []

        # Time-decay bias
        if self.bias_cfg.enable_time_decay:
            B_time = self._time_decay_bias(T, ts_list, device=device)  # [1,T,T]
            B_time = B_time.unsqueeze(0).unsqueeze(0)                  # [1,1,T,T]
            B_time = B_time.expand((1 if self.bias_cfg.share_across_batch else B), H, T, T)
            components.append(B_time)

        # Correlation/similarity prior across time
        if self.bias_cfg.enable_corr_prior:
            # Build from the *batch-averaged* slice embeddings to avoid noise:
            # Flatten per-time slice across A*F into a feature vector, then cosine sim.
            # x_mean: [T, D]
            D = A * F
            x_flat = x.reshape(B, T, D)
            x_mean = x_flat.mean(dim=0)  # [T, D] (shared across batch)
            B_corr = self._time_similarity_bias(x_mean, mode=self.bias_cfg.corr_mode, device=device)  # [T,T]
            B_corr = (self.bias_cfg.gamma_corr * B_corr).unsqueeze(0).unsqueeze(0)  # [1,1,T,T]
            B_corr = B_corr.expand((1 if self.bias_cfg.share_across_batch else B), H, T, T)
            components.append(B_corr)

        if not components:
            return None

        B_total = torch.zeros_like(components[0])
        for c in components:
            B_total = B_total + c
        return B_total  # [B or 1, H, T, T]

    def _time_decay_bias(self, T: int, ts_list: List[Optional[torch.Tensor]], device: torch.device) -> torch.Tensor:
        """
        Build B_time[i,j] = -lambda * max(0, t_i - t_j), i.e., prefer recent context.
        If timestamps provided, use Δt in *time units*; else use step index (Δt = i-j).
        Returns [T,T] (no heads/batch).
        """
        lam = self.bias_cfg.lambda_time
        # Use provided timestamps from the first non-None sample, else 0..T-1
        base_ts = None
        for t in ts_list:
            if t is not None:
                base_ts = t
                break
        if base_ts is None:
            # integer steps
            tvec = torch.arange(T, device=device, dtype=torch.float32)
        else:
            # convert to float deltas (seconds) if datetime64, else assume numeric
            if not torch.is_floating_point(base_ts):
                base_ts = base_ts.to(torch.float32)
            # reindex to 0-based via (ts - ts[0])
            tvec = base_ts - base_ts[0]
            # Avoid negative/NaN
            tvec = torch.nan_to_num(tvec, nan=0.0)

        ti = tvec.view(T, 1)
        tj = tvec.view(1, T)
        delta = torch.clamp(ti - tj, min=0.0)  # (t_i - t_j)+
        return -lam * delta  # [T,T]

    def _time_similarity_bias(self, X: torch.Tensor, mode: str = "cosine", device: torch.device = None) -> torch.Tensor:
        """
        X: [T, D] (batch-averaged per-time embeddings).
        Returns a symmetric [T,T] matrix of similarities to add to logits.
        - "cosine": cosine similarity in [-1,1]
        - "dot":    unnormalized dot product (risk stronger scaling)
        """
        T, D = X.shape
        if mode == "cosine":
            # normalize rows
            Xn = torch.nn.functional.normalize(X, p=2, dim=1)
            S = Xn @ Xn.t()  # [T,T], in [-1,1]
        elif mode == "dot":
            S = X @ X.t()
            # optional: scale by 1/sqrt(D) to match attention scaling
            S = S / (D ** 0.5)
        else:
            raise ValueError("corr_mode must be 'cosine' or 'dot'")
        return S.to(device or X.device)

# --- convenience shims / factories ------------------------------------------

def collate_batch(samples):
    """
    Back-compat shim so `from itoformer.training.collate import collate_batch`
    works. Uses default BiasConfig and no device pinning.
    """
    return CollateBuilder(BiasConfig(), device=None)(samples)


def make_collate(
    bias_cfg: BiasConfig | None = None,
    device: torch.device | None = None
):
    """
    Factory for a configured collate_fn to pass into DataLoader.
    Example:
        collate_fn = make_collate(BiasConfig(n_heads=8, share_across_batch=True), device)
    """
    return CollateBuilder(bias_cfg or BiasConfig(), device=device)

