# src/itoformer/training/tokenization.py
# Baselines don't need patching; this is kept for API symmetry.
from __future__ import annotations
import pandas as pd

def identity_tokens(df: pd.DataFrame) -> pd.DataFrame:
    """No-op tokenization for baselines."""
    return df
