# src/itoformer/training/preprocessing.py
from __future__ import annotations
import numpy as np
import pandas as pd

def to_returns(px: pd.Series, log: bool = True) -> pd.Series:
    px = px.astype("float64")
    if log:
        return np.log(px).diff()
    return px.pct_change()

def zscore_in_sample(s: pd.Series) -> pd.Series:
    mu = s.mean()
    sd = s.std(ddof=1)
    return (s - mu) / (sd if sd > 0 else 1.0)

def align_and_dropna(df: pd.DataFrame, min_non_na: int = None) -> pd.DataFrame:
    out = df.sort_index()
    if min_non_na is None:
        return out.dropna()
    return out.dropna(thresh=min_non_na, axis=0)
