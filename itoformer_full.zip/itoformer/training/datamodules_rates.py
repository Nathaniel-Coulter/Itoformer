#datamodules_rates.py
from __future__ import annotations
import os
import pandas as pd, numpy as np
import torch
from torch.utils.data import Dataset, DataLoader

TENOR_ORDER = ["DGS1MO","DGS3MO","DGS6MO","DGS1","DGS2","DGS3","DGS5","DGS7","DGS10","DGS20","DGS30"]

class _DS(Dataset):
    def __init__(self, X, Y):
        self.X, self.Y = X, Y
    def __len__(self): return len(self.X)
    def __getitem__(self, i):
        return torch.tensor(self.X[i], dtype=torch.float32), torch.tensor(self.Y[i], dtype=torch.float32)

def _merge_many(dfs):
    out = None
    for d in dfs:
        out = d if out is None else out.merge(d, on="date", how="outer")
    return out

def _must_read_csv(p: str) -> pd.DataFrame:
    if not os.path.exists(p):
        raise FileNotFoundError(f"[rates] Missing data file: {p}")
    print(f"[rates] reading: {p}", flush=True)
    return pd.read_csv(p)

def _load_fred_series(path: str, date_col_guess: str = "observation_date") -> pd.DataFrame:
    df = _must_read_csv(path)

    # choose date column (fallback to any column containing "date")
    if date_col_guess in df.columns:
        dcol = date_col_guess
    else:
        cand = [c for c in df.columns if "date" in c.lower()]
        if not cand:
            raise ValueError(f"[rates] No date column found in {path}. Columns: {list(df.columns)}")
        dcol = cand[0]
    df[dcol] = pd.to_datetime(df[dcol], errors="coerce")

    # pick value column = first non-date; coerce numeric
    vcols = [c for c in df.columns if c != dcol]
    if not vcols:
        raise ValueError(f"[rates] No value column found in {path}. Columns: {list(df.columns)}")
    vcol = vcols[0]
    name = os.path.splitext(os.path.basename(path))[0]

    df = df[[dcol, vcol]].rename(columns={dcol: "date", vcol: name})
    df[name] = pd.to_numeric(df[name], errors="coerce")
    return df

class RatesDataModule:
    """
    Minimal term-structure loader compatible with train_rates.py:
      - Loads UST FRED series
      - Monthly resample (optional)
      - X: [L, N] yields (decimals) with yields as the FIRST N features
      - Y: next-step yield LEVELS at horizon H, shape [N]
    """
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.train_ds = None
        self.val_ds = None
        self._tenor_cols = None
        self._N = self._L = self._H = None

    def setup(self):
        files = self.cfg["data"]["files"]

        # --- Load UST curves ---
        ust_paths = list(files["ust_yields"].values())
        ust_frames = [_load_fred_series(p) for p in ust_paths]
        df = _merge_many(ust_frames).sort_values("date").ffill().dropna(subset=["date"])

        # Monthly resample if requested
        if self.cfg.get("data", {}).get("transforms", {}).get("freq") == "monthly":
            df = df.set_index("date").resample("M").last().reset_index()

        # Ensure tenor columns present & ordered
        tenor_cols = [c for c in TENOR_ORDER if c in df.columns]
        if len(tenor_cols) == 0:
            raise ValueError("No DGS* tenor columns found. Check your CSVs/paths.")
        if tenor_cols != TENOR_ORDER[:len(tenor_cols)]:
            tenor_cols = TENOR_ORDER[:len(tenor_cols)]

        # Drop rows missing any tenor and coerce to decimals if needed
        df = df.dropna(subset=tenor_cols, how="any").reset_index(drop=True)
        vals = df[tenor_cols].to_numpy(dtype=np.float64)
        if np.nanmedian(vals) > 1.0:  # percents -> decimals
            vals = vals / 100.0

        # Windowing
        L = int(self.cfg["data"]["splits"]["lookbacks"][0])
        Hs = self.cfg["data"]["splits"]["horizons"]; H = int(Hs[0])
        Xs, Ys = [], []
        N = len(tenor_cols)
        for t in range(L, len(vals) - H):
            Xs.append(vals[t-L:t, :N])   # [L, N]
            Ys.append(vals[t+H, :N])     # [N]
        X = np.asarray(Xs, dtype=np.float32)
        Y = np.asarray(Ys, dtype=np.float32)

        n = len(X)
        if n == 0:
            raise ValueError("Insufficient data after windowing—reduce lookback or check inputs.")
        val_frac = float(self.cfg["data"]["splits"].get("val_fraction", 0.2))
        n_val = max(1, int(n * val_frac))

        self.train_ds = _DS(X[:-n_val], Y[:-n_val]) if n_val < n else _DS(X, Y)
        self.val_ds   = _DS(X[-n_val:], Y[-n_val:]) if n_val < n else _DS(X[-1:], Y[-1:])

        # Save for debug
        self._tenor_cols, self._N, self._L, self._H = tenor_cols, N, L, H
        print(f"[rates] tenors={tenor_cols} N={N} L={L} H={H} train={len(self.train_ds)} val={len(self.val_ds)}", flush=True)

    def train_loader(self):
        lc = self.cfg["data"]["loader"]
        return DataLoader(
            self.train_ds,
            batch_size=int(lc.get("batch_size", 64)),
            shuffle=bool(lc.get("shuffle", True)),
            num_workers=int(lc.get("num_workers", 0)),
            pin_memory=bool(lc.get("pin_memory", True)),
        )

    def val_loader(self):
        lc = self.cfg["data"]["loader"]
        return DataLoader(
            self.val_ds,
            batch_size=int(lc.get("batch_size", 64)),
            shuffle=False,
            num_workers=int(lc.get("num_workers", 0)),
            pin_memory=bool(lc.get("pin_memory", True)),
        )
