# src/itoformer/training/datasets.py
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple, Dict, Optional
from .preprocessing import to_returns as _to_returns

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader

# --- robust CSV loader: picks date + price columns defensively ---
def _load_asset_series(csv_path: Path) -> pd.Series:
    """
    Robust loader: returns a clean price series named 'px' with a DatetimeIndex.
    Handles common schemas (yfinance, generic vendor CSVs), stray text, and commas.
    """
    df = pd.read_csv(csv_path)

    # --- 1) find/parse date column ---
    date_candidates = ["date", "Date", "DATE", "timestamp", "Timestamp"]
    date_col = next((c for c in date_candidates if c in df.columns), None)
    if date_col is None:
        # fallback: try the first column if it parses as dates
        first_col = df.columns[0]
        try:
            pd.to_datetime(df[first_col])
            date_col = first_col
        except Exception:
            raise ValueError(f"Could not locate a date column in {csv_path}. "
                             f"Columns: {list(df.columns)}")

    df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
    df = df.dropna(subset=[date_col]).sort_values(date_col).set_index(date_col)

    # --- 2) pick a price column ---
    preferred = [
        "adj_close", "Adj Close", "adjclose",
        "close", "Close",
        "PX_LAST", "px_last",
        "price", "Price",
    ]

    def numeric_score(s: pd.Series) -> int:
        # count numeric (non-NaN) after coercion; strips commas
        coerced = pd.to_numeric(s.astype(str).str.replace(",", ""), errors="coerce")
        return int(coerced.notna().sum())

    price_col = None
    for c in preferred:
        if c in df.columns and numeric_score(df[c]) > 5:
            price_col = c
            break

    if price_col is None:
        # fallback: most-numeric column
        scores = sorted(
            ((c, numeric_score(df[c])) for c in df.columns),
            key=lambda t: t[1],
            reverse=True,
        )
        if scores and scores[0][1] > 5:
            price_col = scores[0][0]

    if price_col is None:
        raise ValueError(f"Could not find a numeric price column in {csv_path}. "
                         f"Columns: {list(df.columns)}")

    # --- 3) coerce to float, drop junk rows ---
    px = pd.to_numeric(
        df[price_col].astype(str).str.replace(",", ""),
        errors="coerce"
    ).dropna()
    px.name = "px"

    if px.empty:
        raise ValueError(f"After cleaning, price series is empty in {csv_path}")

    return px

def _stack_panel(panel: Dict[str, pd.Series]) -> pd.DataFrame:
    """
    Align on the intersection of dates and return a [date x assets] DataFrame.
    """
    # Concat each asset series into columns, align on common dates
    df = pd.concat(panel, axis=1)          # columns: asset tickers
    # Ensure datetime index & sorted
    df.index = pd.to_datetime(df.index)
    df = df.sort_index()
    # Drop any rows with missing assets (strict intersection)
    df = df.dropna(how="any")
    return df

# --- dataset -----------------------------------------------------------------

@dataclass
class PanelMeta:
    max_len: int
    dates: List[pd.Timestamp]
    assets: List[str]

class EquitiesDataset(Dataset):
    """
    Emits (X, Y) or (X, Y, bias) for forecasting next-step returns.

    X: [T_window, A, F]   (here F=1: returns only)
    Y: [T_window, A]      (next-step returns aligned with X positions)
    """
    def __init__(
        self,
        R: np.ndarray,           # [T, A] returns
        window: int = 64,
        pred_horizon: int = 1,
        features_per_asset: int = 1,
        include_bias: bool = False,
    ):
        super().__init__()
        self.R = R.astype(np.float32)
        self.T, self.A = R.shape
        self.window = window
        self.h = pred_horizon
        self.F = features_per_asset
        self.include_bias = include_bias
        # last start index where we can take window then predict h ahead
        self.max_start = self.T - (self.window + self.h)
        if self.max_start < 0:
            raise ValueError("Time series too short for given window/horizon.")

    def __len__(self) -> int:
        return self.max_start + 1

    def __getitem__(self, idx: int):
        # X spans [idx : idx+window), predict Y at [idx+1 : idx+window+1) (next-step)
        sl_x = slice(idx, idx + self.window)
        sl_y = slice(idx + 1, idx + self.window + 1)

        x = self.R[sl_x]                 # [W, A]
        y = self.R[sl_y]                 # [W, A]
        # add feature dim F=1 → [W, A, 1]
        x = x[:, :, None]

        x = torch.from_numpy(x)          # [W, A, 1]
        y = torch.from_numpy(y)          # [W, A]

        if self.include_bias:
            # placeholder for attention bias [H, W, W]; not used yet
            bias = torch.zeros(1, 1, self.window, self.window, dtype=torch.float32)
            return x, y, bias
        else:
            return x, y

# --- public builder -----------------------------------------------------------

def build_equities_dataloaders(
    data_root: Path,
    assets: List[str],
    batch_size: int = 64,
    window: int = 128,
    pred_horizon: int = 1,
    val_ratio: float = 0.2,
    shuffle_train: bool = True,
    features_per_asset: int = 1,
    include_bias: bool = False,
) -> Tuple[DataLoader, DataLoader, Dict[str, int]]:
    """
    Load CSVs under data_root/<TICKER>.csv, align, compute returns, and
    return train/val DataLoaders plus a meta dict.
    """
    # Load each asset, convert to returns
    panel = {}
    for a in assets:
        p = data_root / f"{a}.csv"
        if not p.exists():
            raise FileNotFoundError(f"Missing CSV: {p}")
        px = _load_asset_series(p)
        px.name = a
        r = _to_returns(px)
        panel[a] = r

    R_df = _stack_panel(panel)                             # [date x A]
    dates = R_df.index.to_list()
    R = R_df.values                                       # [T, A]
    T, A = R.shape

    # split train/val by time
    val_len = max(int(T * val_ratio), 1)
    train_len = T - val_len
    R_train = R[:train_len]
    R_val   = R[train_len - window - 1:]  # ensure we have enough history for first val window

    ds_train = EquitiesDataset(
        R_train, window=window, pred_horizon=pred_horizon,
        features_per_asset=features_per_asset, include_bias=include_bias
    )
    ds_val = EquitiesDataset(
        R_val, window=window, pred_horizon=pred_horizon,
        features_per_asset=features_per_asset, include_bias=include_bias
    )

    train_loader = DataLoader(
        ds_train, batch_size=batch_size, shuffle=shuffle_train, drop_last=True
    )
    val_loader = DataLoader(
        ds_val, batch_size=batch_size, shuffle=False, drop_last=False
    )

    meta = {
        "max_len": window,
        "n_obs": T,
        "n_assets": A,
        "train_len": len(ds_train),
        "val_len": len(ds_val),
    }
    return train_loader, val_loader, meta

__all__ = ["build_equities_dataloaders", "EquitiesDataset", "PanelMeta"]
