# src/itoformer/training/datamodules_options.py
from __future__ import annotations
from typing import Dict, Any, Tuple, Optional, List
import pandas as pd
import numpy as np
import math
import torch
from torch.utils.data import Dataset, DataLoader


# ------------------------------ Dataset ------------------------------

class _TimeWindowDataset(Dataset):
    """
    Holds rolling windows (X, Y) plus aligned meta (strike/dte/cp) for the Y point.
    """
    def __init__(self, X: np.ndarray, Y: np.ndarray, meta: Dict[str, np.ndarray]):
        self.X, self.Y, self.meta = X, Y, meta

    def __len__(self) -> int:
        return len(self.X)

    def __getitem__(self, i: int):
        x = torch.tensor(self.X[i]).float()
        y = torch.tensor(self.Y[i]).float()
        m = {k: torch.tensor(v[i]) for k, v in self.meta.items()}  # tensors: shape []
        return x, y, m


# ------------------------------ Helpers ------------------------------

def _rolling_windows_with_meta(
    df: pd.DataFrame,
    lookback: int,
    horizon: int,
    feature_cols: List[str],
    target_cols: List[str],
    meta_cols: Tuple[str, str, str] = ("strike", "dte", "cp"),
) -> Tuple[np.ndarray, np.ndarray, Dict[str, np.ndarray]]:
    """
    Create rolling windows and carry meta aligned to the Y timestamp (t + horizon).
    X: [N, lookback, F]
    Y: [N, T_targets]
    meta: dict of arrays length N (each scalar per row)
    """
    arrF = df[feature_cols].values
    arrT = df[target_cols].values

    # meta arrays, if present; else fill NaNs
    meta_arrays: Dict[str, np.ndarray] = {}
    for col in meta_cols:
        if col in df.columns:
            meta_arrays[col] = df[col].values
        else:
            meta_arrays[col] = np.full((len(df),), np.nan, dtype=float)

    Xs, Ys = [], []
    M: Dict[str, list] = {k: [] for k in meta_cols}
    T = len(df)

    for t in range(lookback, T - horizon):
        Xs.append(arrF[t - lookback:t])
        Ys.append(arrT[t + horizon])
        for k in meta_cols:
            M[k].append(meta_arrays[k][t + horizon])

    X = np.array(Xs)
    Y = np.array(Ys)
    meta_out = {k: np.asarray(v) for k, v in M.items()}

    # If cp is string/categorical, map to {Call:1, Put:0}
    cp_arr = meta_out.get("cp", None)
    if cp_arr is not None and (cp_arr.dtype.kind in ("U", "S", "O")):
        cp_norm = []
        for v in cp_arr:
            s = str(v).strip().lower()
            if s in ("c", "call", "calls"):
                cp_norm.append(1.0)
            elif s in ("p", "put", "puts"):
                cp_norm.append(0.0)
            else:
                cp_norm.append(np.nan)
        meta_out["cp"] = np.array(cp_norm, dtype=float)

    return X, Y, meta_out


def _first_numeric_column(df: pd.DataFrame, exclude=("date",)) -> Optional[str]:
    for c in df.columns:
        if c in exclude:
            continue
        if pd.api.types.is_numeric_dtype(df[c]):
            return c
    return None


# ------------------------------ DataModules ------------------------------

class OptionsNodesDataModule:
    """
    Path A: node-wise IV/Greeks. Expects:
      cfg['data']['files']['nodes'] -> spx_latest.csv
      cfg['data']['files']['aux'] -> dict of auxiliary CSVs (vix, vvix, skew, rvol_hvg, spx, spx_div)
      cfg['data']['schema'] -> column names (date_col, expiration_col, dte_col, call_put_col, strike_col, iv_col, delta_col, ...)
      cfg['data']['filters'] -> delta_band, dte_windows
      cfg['data']['splits'] -> lookbacks, horizons, val_fraction, rolling
      cfg['data'] -> max_days, max_strikes_per_bucket (optional caps)
    """

    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.train_ds: Optional[_TimeWindowDataset] = None
        self.val_ds: Optional[_TimeWindowDataset] = None
        self.feature_names: Optional[List[str]] = None  # exposed for best-effort meta extraction

    # -------- robust chain loader --------
    def _load_chain(self) -> pd.DataFrame:
        path = self.cfg["data"]["files"]["nodes"]
        sch = self.cfg["data"]["schema"]

        raw = pd.read_csv(path)

        # Build robust rename map
        rename_map: Dict[str, str] = {}

        def map_if_present(src: Optional[str], dst: str):
            if src and src in raw.columns:
                rename_map[src] = dst

        map_if_present(sch.get("date_col"),        "date")
        map_if_present(sch.get("expiration_col"),  "expiration")
        map_if_present(sch.get("dte_col"),         "dte")
        map_if_present(sch.get("strike_col"),      "strike")
        map_if_present(sch.get("iv_col"),          "iv")
        map_if_present(sch.get("delta_col"),       "delta")
        map_if_present(sch.get("gamma_col"),       "gamma")
        map_if_present(sch.get("vega_col"),        "vega")
        map_if_present(sch.get("theta_col"),       "theta")
        map_if_present(sch.get("rho_col"),         "rho")

        # cp / call_put aliases
        cp_aliases = [
            sch.get("call_put_col"),
            "cp", "call_put", "CALL_PUT", "option_type", "opt_type", "type"
        ]
        for cand in cp_aliases:
            if cand and cand in raw.columns:
                rename_map[cand] = "cp"
                break

        df = raw.rename(columns=rename_map).copy()

        # If cp still missing, create placeholder to avoid KeyError later
        if "cp" not in df.columns:
            print("[WARN] call/put column not found; setting cp='Unknown' for all rows.")
            df["cp"] = "Unknown"

        # Basic typing
        if "date" in df.columns:
            df["date"] = pd.to_datetime(df["date"], errors="coerce")

        # Filters
        band = tuple(self.cfg["data"]["filters"]["delta_band"])
        dte_windows = list(self.cfg["data"]["filters"]["dte_windows"])

        mask = True
        if "delta" in df.columns:
            mask = df["delta"].abs().between(*band)

        dte_mask = pd.Series(False, index=df.index)
        if "dte" in df.columns:
            for lo, hi in dte_windows:
                dte_mask |= df["dte"].between(lo, hi)
        else:
            dte_mask[:] = True

        df = df[mask & dte_mask]

        # Group by available keys (keep strike if present)
        group_cols = [c for c in ["date", "expiration", "dte", "cp", "strike"] if c in df.columns]
        if not group_cols:
            raise ValueError("No valid grouping columns found in options chain.")
        df = df.groupby(group_cols, as_index=False).median(numeric_only=True)

        return df

    def _load_aux(self) -> pd.DataFrame:
        aux_cfg = self.cfg["data"]["files"].get("aux", {})
        out = None
        for key, path in aux_cfg.items():
            if not path:
                continue
            dfa = pd.read_csv(path)

            # Normalize date header
            for dc in ("Date", "date", "observation_date"):
                if dc in dfa.columns:
                    dfa[dc] = pd.to_datetime(dfa[dc], errors="coerce")
                    dfa = dfa.rename(columns={dc: "date"})
                    break

            vcol = _first_numeric_column(dfa, exclude=("date",))
            if not vcol:
                continue

            dfa = dfa[["date", vcol]].rename(columns={vcol: key})
            out = dfa if out is None else out.merge(dfa, on="date", how="outer")

        if out is None:
            out = pd.DataFrame(columns=["date"])
        return out.sort_values("date").ffill()

    def setup(self):
        # Load primary chain
        df = self._load_chain()

        # Load auxiliary features
        aux = self._load_aux()

        # Harmonize date types before merging
        if "date" in df.columns:
            df["date"] = pd.to_datetime(df["date"], errors="coerce")
        if "date" in aux.columns:
            aux["date"] = pd.to_datetime(aux["date"], errors="coerce")

        # Merge & forward-fill
        df = df.merge(aux, on="date", how="left").sort_values("date").ffill()
        df = df.loc[:, ~df.columns.duplicated()].copy()

        # 1) Limit to most recent N days (Option B)
        N_DAYS = int(self.cfg.get("data", {}).get("max_days", 120))
        if "date" in df.columns and N_DAYS is not None:
            cutoff = df["date"].max() - pd.Timedelta(days=N_DAYS)
            df = df[df["date"] >= cutoff]

        # 2) Cap strikes per (date, dte, cp) (Option B)
        MAX_STRIKES = int(self.cfg.get("data", {}).get("max_strikes_per_bucket", 12))

        def _cap_group(g: pd.DataFrame) -> pd.DataFrame:
            if ("strike" not in g.columns) or (len(g) <= MAX_STRIKES):
                return g
            qs = np.linspace(0, 1, MAX_STRIKES + 2)[1:-1]
            cuts = g["strike"].quantile(qs).values
            idx = [(g["strike"] - c).abs().idxmin() for c in cuts]
            return g.loc[sorted(set(idx))]

        group_for_cap = [c for c in ["date", "expiration", "dte", "cp"] if c in df.columns]
        if group_for_cap:
            df = (
                df.sort_values(group_for_cap)
                .groupby(group_for_cap, group_keys=False, sort=False)
                .apply(_cap_group, include_groups=False)
            )

        # 3) Force float32 to reduce memory
        for col in df.columns:
            if pd.api.types.is_float_dtype(df[col]):
                df[col] = df[col].astype("float32")

        # Features / targets
        feats   = list(self.cfg["data"]["features"]["include"])
        targets = list(self.cfg["data"]["targets"]["predict"])

        feature_cols = [c for c in feats if c in df.columns]
        # Optionally append core option state to inputs (kept as in your previous code)
        for c in ["iv", "delta", "gamma", "vega", "theta"]:
            if c in df.columns and c not in feature_cols:
                feature_cols.append(c)

        target_cols = [c for c in targets if c in df.columns]
        if not feature_cols:
            raise ValueError("No feature columns found after merging. Check data.features.include and CSVs.")
        if not target_cols:
            raise ValueError("No target columns found in dataframe. Check data.targets.predict and CSV headers.")

        # Numeric guard
        for c in set(feature_cols + target_cols):
            if c in df.columns and not pd.api.types.is_numeric_dtype(df[c]):
                df[c] = pd.to_numeric(df[c], errors="coerce")

        #ENSURE WE KEEP SLICE KEYS (even if they aren't listed as features / targets)
        must_keep = ["date", "expiration", "dte", "cp", "strike", "iv"]
        for c in must_keep:
            if c in df.columns and c not in feature_cols:
                feature_cols.append(c)
        
        cols = []
        for c in (feature_cols + target_cols):
            if c in df.columns and c not in cols:
                cols.append(c)
        df = df[cols]

        # --- DEBUG INSPECT ---
        print(f"\n[DEBUG] df.shape after merge: {df.shape}")
        print(f"[DEBUG] df.columns: {list(df.columns)}")
        print(f"[DEBUG] head:\n{df.head(3)}\n")

        # Rolling windows + meta
        L = int(self.cfg["data"]["splits"]["lookbacks"][0])
        H = int(self.cfg["data"]["splits"]["horizons"][0])
        df_clean = df.dropna(subset=feature_cols + target_cols)
        X, Y, M = _rolling_windows_with_meta(df_clean, L, H, feature_cols, target_cols)

        # Expose feature names (for best-effort meta lookup in train loop if needed)
        self.feature_names = feature_cols

        # Train/val split
        n = len(X)
        val_frac = float(self.cfg["data"]["splits"]["val_fraction"])
        n_val = int(n * val_frac)

        if n_val > 0:
            self.train_ds = _TimeWindowDataset(X[:-n_val], Y[:-n_val], {k: v[:-n_val] for k, v in M.items()})
            self.val_ds   = _TimeWindowDataset(X[-n_val:],  Y[-n_val:],  {k: v[-n_val:]  for k, v in M.items()})
        else:
            self.train_ds = _TimeWindowDataset(X, Y, M)
            # minimal non-empty val to keep loaders happy
            self.val_ds   = _TimeWindowDataset(X[-1:], Y[-1:], {k: v[-1:] for k, v in M.items()})

    def train_loader(self):
        lc = self.cfg["data"].get("loader", {})
        return DataLoader(
            self.train_ds,
            batch_size=int(lc.get("batch_size", 64)),
            shuffle=bool(lc.get("shuffle", True)),
            num_workers=int(lc.get("num_workers", 0)),   # Windows-safe
            pin_memory=bool(lc.get("pin_memory", True)),
        )

    def val_loader(self):
        lc = self.cfg["data"].get("loader", {})
        return DataLoader(
            self.val_ds,
            batch_size=int(lc.get("batch_size", 64)),
            shuffle=False,
            num_workers=int(lc.get("num_workers", 0)),   # Windows-safe
            pin_memory=bool(lc.get("pin_memory", True)),
        )


class OptionsSVIDataModule:
    """
    Path B: SVI parameter regression. Produces batches where each item is a
    (date × expiry) slice with variable-length strike/iv arrays for SVI fitting.
    """
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.train_ds: Optional[_TimeWindowDataset] = None
        self.val_ds: Optional[_TimeWindowDataset] = None
        self._train_slices = []
        self._val_slices = []
        self._test_slices = []

    def setup(self):
        base = OptionsNodesDataModule(self.cfg)
        base.setup()

        # Reuse robust loaders from nodes
        df  = base._load_chain()   # filtered + grouped per nodes rules
        aux = base._load_aux()

        # Harmonize date types and merge
        if "date" in df.columns:
            df["date"] = pd.to_datetime(df["date"], errors="coerce")
        if "date" in aux.columns:
            aux["date"] = pd.to_datetime(aux["date"], errors="coerce")

        df = df.merge(aux, on="date", how="left").sort_values("date").ffill()

        # (2) kill any duplicate columns (e.g., "iv" twice)
        df = df.loc[:, ~df.columns.duplicated()].copy()

        # Standardize key column names if alternatives appear
        aliases = {
            "date": ["date", "trade_date", "quote_date"],
            "expiration": ["expiration", "exdate", "maturity"],
            "dte": ["dte", "days_to_expiration", "ttm_days", "days"],
            "cp": ["cp", "call_put", "option_type"],
        }
        def pick(name):
            for c in aliases[name]:
                if c in df.columns:
                    return c
            return None

        for std, col in [
            ("date", pick("date")),
            ("expiration", pick("expiration")),
            ("dte", pick("dte")),
            ("cp", pick("cp")),
        ]:
            if col and col != std:
                df.rename(columns={col: std}, inplace=True)

        if "date" in df.columns:
            df["date"] = pd.to_datetime(df["date"], errors="coerce")
        if "expiration" in df.columns:
            df["expiration"] = pd.to_datetime(df["expiration"], errors="coerce")

        # (1) quick check that we actually have expiration/dte
        print("[SVI] cols before slice:", [c for c in df.columns if c in ("date","expiration","dte")][:10])

        # Grouping keys: prefer (date, expiration), fallback to (date, dte)
        gkeys = [c for c in ["date", "expiration"] if c in df.columns]
        if not gkeys:
            gkeys = [c for c in ["date", "dte"] if c in df.columns]
        if not gkeys:
            raise ValueError("No valid (date, expiration/dte) keys found for SVI grouping.")

        # Hygiene: assert we have strike/iv
        for req in ("strike", "iv"):
            if req not in df.columns:
                raise ValueError(f"Required column '{req}' not found for SVI.")

        min_q = int(self.cfg["data"]["filters"]["min_quotes_per_bucket"])
        slices, n_groups, n_kept = [], 0, 0

        # Use default groupby (no as_index=False) so g is scalar or tuple
        for g, gdf in df.groupby(gkeys):
            n_groups += 1
            gdf = gdf.dropna(subset=["strike", "iv"])
            if len(gdf) < min_q:
                continue
            n_kept += 1

            item = {
                "date":   g[0] if isinstance(g, tuple) else g,
                "expiry": g[1] if isinstance(g, tuple) and len(g) > 1 else None,
                "dte":    float(gdf["dte"].iloc[0]) if "dte" in gdf.columns else float("nan"),
                "strike": gdf["strike"].to_numpy(dtype="float32"),
                "iv":     gdf["iv"].to_numpy(dtype="float32"),
                # carry spot/rate/div if available (used to compute forward -> log-moneyness)
                "spot": float(gdf["spx"].iloc[0])     if "spx"     in gdf.columns else float("nan"),
                "rate": float(gdf["rate"].iloc[0])    if "rate"    in gdf.columns else 0.0,
                "div":  float(gdf["spx_div"].iloc[0]) if "spx_div" in gdf.columns else 0.0,
            }
            slices.append(item)

        drop_rate = 0.0 if n_groups == 0 else 1.0 - (n_kept / n_groups)
        if drop_rate > 0.4:
            print(f"[SVI][WARN] {drop_rate:.1%} of groups dropped for min_quotes_per_bucket={min_q}. "
                  f"(kept {n_kept}/{n_groups})")

        print(f"[SVI] built {len(slices)} (date×expiry) slices, min_quotes_per_bucket={min_q}")

        def _dte_key(x):
            v = x.get("dte", float("nan"))
            return math.inf if (v != v) else float(v)
        
        def _exp_key(x):
            e = x.get("expiry", None)
            return "" if e is None else str(e)
        
        slices.sort(key=lambda r: (pd.Timestamp(r["date"]), _dte_key(r)))

        # ---- Train/Val/Test split on slices (by time order) ----
        n = len(slices)
        val_frac  = float(self.cfg["data"]["splits"].get("val_fraction", 0.2))
        test_frac = float(self.cfg["data"]["splits"].get("test_fraction", 0.0))
        n_test = int(round(n * test_frac))
        n_val  = int(round((n - n_test) * val_frac))

        # chronological split: train | val | test
        self._train_slices = slices[: max(0, n - n_val - n_test)]
        self._val_slices   = slices[max(0, n - n_val - n_test) : max(0, n - n_test)]
        self._test_slices  = slices[max(0, n - n_test) :]

        print(f"[SVI] split -> train:{len(self._train_slices)}  "
              f"val:{len(self._val_slices)}  test:{len(self._test_slices)}")

        # Dummy X to satisfy encoder input shape; adjust when you wire real features
        def make_ds(slc):
            X = torch.zeros((len(slc), 128, 256), dtype=torch.float32)  # [B, L, d_model]
            Y = torch.zeros((len(slc), 5), dtype=torch.float32)         # 5 params target placeholder
            meta = {"slice_ix": torch.arange(len(slc), dtype=torch.int64)}
            return _TimeWindowDataset(
                X.numpy(),
                Y.numpy(),
                {k: v.numpy() if hasattr(v, "numpy") else v for k, v in meta.items()},
            )

        self.train_ds = make_ds(self._train_slices)
        self.val_ds   = make_ds(self._val_slices)
        # (optional) if you later add a test loader, reuse make_ds(self._test_slices)

    def train_loader(self):
        lc = self.cfg["data"].get("loader", {})
        return DataLoader(
            self.train_ds,
            batch_size=int(lc.get("batch_size", 64)),
            shuffle=True,
            num_workers=0,                     # Windows-safe
            pin_memory=bool(lc.get("pin_memory", True)),
            collate_fn=self._collate_svi(self._train_slices),
        )

    def val_loader(self):
        lc = self.cfg["data"].get("loader", {})
        return DataLoader(
            self.val_ds,
            batch_size=int(lc.get("batch_size", 64)),
            shuffle=False,
            num_workers=0,                     # Windows-safe
            pin_memory=bool(lc.get("pin_memory", True)),
            collate_fn=self._collate_svi(self._val_slices),
        )

    @staticmethod
    def _collate_svi(repo_slices):
        def fn(batch):
            Xs, Ys, metas = zip(*batch)
            xb = torch.stack(Xs, dim=0).float()   # [B, L, d_model]
            yb = torch.stack(Ys, dim=0).float()   # [B, 5]
            idxs = [int(m["slice_ix"].item()) for m in metas]
            slices = [repo_slices[i] for i in idxs]  # includes strike/iv/date/dte/expiry/spot/rate/div
            return xb, yb, slices
        return fn
